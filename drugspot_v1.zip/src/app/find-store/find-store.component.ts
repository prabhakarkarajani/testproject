import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { debounceTime, distinctUntilChanged, map } from 'rxjs/operators';
import { HttpConnectorService } from "src/app/shared/service/http-connector.service";
import { environment } from "src/environments/environment";
import { DataSharingService } from "src/app/core/services/data-sharing.service";
@Component({
  selector: 'app-find-store',
  templateUrl: './find-store.component.html',
  styleUrls: ['./find-store.component.css']
})
export class FindStoreComponent implements OnInit {
  public medicineData: any;
  public model: any;
  public searchArr: any;
  public medicineUse:String;
  constructor(private HttpConnector: HttpConnectorService, private dataSharedService: DataSharingService) { }

  ngOnInit() {
    this.HttpConnector.getRequest(environment.GET_MED_DATA).subscribe(response => {
      this.dataSharedService.getMedData = response;
      const dupArr = this.dataSharedService.getMedData.map(obj => obj.name);
      this.medicineData =  Array.from(new Set(dupArr))
      // this.medicineData = dupArr.filter((value) => {
      //   return !this[value] && (this[value] = true)
      // }, Object.create(null))
      console.log(this.medicineData)
    });

    this.HttpConnector.getRequest(environment.GET_MEDICINE_INFO).subscribe(response => {
      this.dataSharedService.getMedicineInfo = response;
    })

  }

  search = (text$: Observable<string>) => text$.pipe(debounceTime(200), distinctUntilChanged(), map(term => term === '' ? [] : this.medicineData.filter(v => v.toLowerCase().indexOf(term.toLowerCase()) > -1).slice(0, 10)));

  /**search handler */
  getMedicineData(data) {
    this.searchArr = [];
    this.searchArr = this.dataSharedService.getMedData.filter(obj => obj.name === data);
    this.medicineUse = this.dataSharedService.getMedicineInfo[data];    
  }
}
