import { TestBed, inject } from '@angular/core/testing';

import { MedDbService } from './med-db.service';

describe('MedDbService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [MedDbService]
    });
  });

  it('should be created', inject([MedDbService], (service: MedDbService) => {
    expect(service).toBeTruthy();
  }));
});
