import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FindStoreComponent } from './find-store/find-store.component';
import { LoginComponent } from './core/login/login.component';
import { SignupComponent } from './core/signup/signup.component';
import { PageNotFoundComponent } from './core/page-not-found/page-not-found.component';
import { AuthGuard } from './auth.guard';

const routes: Routes = [{
  path: '',
  pathMatch: 'full',
  redirectTo: 'find-store'
},
{
  path: 'find-store',
  component: FindStoreComponent,
  canActivate: [AuthGuard],
},
{
  path: 'login',
  component: LoginComponent
},
{
  path: 'signup',
  component: SignupComponent
},
{
  path:'**',
  component: PageNotFoundComponent
}
]

@NgModule({
  imports: [
    RouterModule.forRoot(routes)
  ],
  exports: [
    RouterModule
  ]

})
export class AppRoutingModule { }

