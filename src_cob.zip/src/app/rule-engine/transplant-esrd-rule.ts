import { RuleEngineUtils } from "src/app/rule-engine/rule-engine-utils";
import { Configurtion } from "src/app/rule-engine/configuration";

export class TransplantESRDRule implements Rule {
    private input;
    private eventsList;
    private corordinationDateList;
    public constructor(input: any, corordinationDateList: any, eventsList?: any) {
        this.input = input;
        this.eventsList = eventsList;
        this.corordinationDateList = corordinationDateList;
    }
    execute(): any {
        //Caliculating coordination start date excluding waiting period
        //Coordination Periods always start on the first of a month.
        let coord_start_date = RuleEngineUtils.addonMonths(this.input["treatment"], 0);
        //Coordination Period lasts for a default 30 months.
        let coord_end_date = RuleEngineUtils.addonMonths(this.input["treatment"], Configurtion.COORDINATION_PERIOD_DURATON);
        //Coordination start dates start with 1st of the month
        coord_start_date = RuleEngineUtils.setDayInMonth(coord_start_date, 1);
        //Get the maximum days in a month
        let maxDaysinMonth = RuleEngineUtils.getMaximumDaysInaMonth(coord_end_date);
        ///Coordination end dates end's with last day of the month
        coord_end_date = RuleEngineUtils.setDayInMonth(coord_end_date, maxDaysinMonth);
        //
        let entitlement_end = RuleEngineUtils.addonMonths(this.input["treatment"], Configurtion.ESRD_TERMINATAION_TRANSPLANT_DURATION);
        let entitleEndMaxDaysinMonth = RuleEngineUtils.getMaximumDaysInaMonth(entitlement_end);
        entitlement_end = RuleEngineUtils.setDayInMonth(entitlement_end, entitleEndMaxDaysinMonth);
        this.input["coordination_start"] = coord_start_date;
        this.input["coordination_end"] = coord_end_date;
        this.input["entitlement_start"] = coord_start_date;
        this.input["entitlement_end"] = entitlement_end;
        //Checking for overlapping coordination dates with previous list of coordination period dates
        let isCoordinationPeriodOverlapped = false;
        this.corordinationDateList.forEach((element, index) => {
            //entitlement period is over
            if (element.entitlement_end && element.entitlement_end != "infinity") {
                if (new Date(coord_start_date) < new Date(element["entitlement_end"])) {
                    isCoordinationPeriodOverlapped = true;
                }
            } else {
                //if entitlment end date is assigned to infinity 
                if (new Date(coord_start_date) < new Date(element["coordination_end"]) || new Date(coord_start_date) > new Date(element["coordination_end"])) {
                    isCoordinationPeriodOverlapped = true;
                    //If Home Training or Transplant occur within the 3-Month In-Center wait period, 
                    //then In-Center wait period is waived, and the coordination period start date is changed/backdated 
                    //based on first In-Center treatment date 
                    if (element["event"] === "incenter") {
                        var homeTrainingCoOrdStartDate = new Date(this.input["coordination_start"]);
                        var inCenterCoOrdTreatmentDate = new Date(element["treatment"]);
                        /*if (new Date(new Date(element["coordination_start"])) === new Date(new Date(element["treatment"]).setDate(1))) {

                        } else*/ if (new Date(new Date(element["coordination_start"])) > new Date(new Date(element["treatment"]).setDate(1)) && (homeTrainingCoOrdStartDate.getMonth() > inCenterCoOrdTreatmentDate.getMonth() && homeTrainingCoOrdStartDate.getMonth() < (inCenterCoOrdTreatmentDate.getMonth() + 3))) {
                            this.corordinationDateList[index]["coordination_start"] = RuleEngineUtils.setDayInMonth(RuleEngineUtils.addonMonths(element["treatment"], 0), 1);
                            //Get the maximum days in a month from coordination end date
                            let cord_end = RuleEngineUtils.addonMonths(element["treatment"], Configurtion.COORDINATION_PERIOD_DURATON);
                            let maxDaysinMonth = RuleEngineUtils.getMaximumDaysInaMonth(cord_end);
                            ///Coordination end dates end's with last day of the month                            
                            this.corordinationDateList[index]["coordination_end"] = RuleEngineUtils.setDayInMonth(cord_end, maxDaysinMonth);
                            //entitlement start date is always equal to coordination start date
                            this.corordinationDateList[index]["entitlement_start"] = this.corordinationDateList[index]["coordination_start"];
                            let entitlement_end = RuleEngineUtils.addonMonths(element["treatment"], Configurtion.ESRD_TERMINATAION_TRANSPLANT_DURATION);
                            let entitleEndMaxDaysinMonth = RuleEngineUtils.getMaximumDaysInaMonth(entitlement_end);
                            entitlement_end = RuleEngineUtils.setDayInMonth(entitlement_end, entitleEndMaxDaysinMonth);
                            this.corordinationDateList[index]["entitlement_end"] = entitlement_end;
                        }
                    }
                }
            }
        });
        if (!isCoordinationPeriodOverlapped) {
            this.corordinationDateList.push(this.input);
        }
        console.log(this.corordinationDateList);
        return this.corordinationDateList;
    }
}
