interface Rule{
    execute():any;
} 