export class RuleEngine{
    static run(rules:Rule[]){
      rules.forEach((element:Rule)=>{
       element.execute();
      })
    }
}