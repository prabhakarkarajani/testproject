import { Injectable } from '@angular/core';

export class RuleEngineUtils {
  static l10nEN = new Intl.DateTimeFormat("en-US");
  constructor() {
  }

  /*
   Add months to date
   */
  public static addonMonths(date: string, months: number): string {
    let futureDate = this.l10nEN.format(new Date(new Date(date).setMonth(new Date(date).getMonth() + months)));
    return futureDate;
  }

  public static setDayInMonth(date: string, day: number): string {
    let modifiedDate = this.l10nEN.format(new Date(new Date(date).setDate(day)));
    return modifiedDate;
  }

  public static getMaximumDaysInaMonth(date: string): number {
    let date1 = this.l10nEN.format(new Date(date));
    let maxDaysInaMonth = this.l10nEN.format(new Date(new Date(date1).getFullYear(), new Date(date1).getMonth()+1,0));
    return new Date(maxDaysInaMonth).getDate();
  }

  
}
