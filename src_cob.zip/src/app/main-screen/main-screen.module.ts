import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MainScreenRoutingModule } from './main-screen-routing.module';
import { SharedModule } from "src/app/shared/shared.module";
import { MainScreenComponent } from "src/app/main-screen/main-screen/main-screen.component";
import { EsrdComponent } from "src/app/main-screen/esrd/esrd.component";
import { NgbModule } from "@ng-bootstrap/ng-bootstrap";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


@NgModule({
  imports: [
    CommonModule,
    MainScreenRoutingModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    NgbModule.forRoot()
  ],
  declarations: [MainScreenComponent,EsrdComponent]
})
export class MainScreenModule { }
