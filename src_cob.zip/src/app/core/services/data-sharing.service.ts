import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DataSharingService {

test:string = "test inital";
getTaskData:any = {};
coordinationDates = [];
repName:string = "";
id:number = 0;
  constructor() { }
}
