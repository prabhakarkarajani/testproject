import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';

import { AuthService } from "src/app/core/services/auth.service";
import { HttpErrorHandler } from "src/app/core/errorHendler/HttpErrorHandler";
import { RequestInterceptor } from "src/app/core/services/request.interceptor";
import { ErrorHandler } from "@angular/core";

import { HTTP_INTERCEPTORS } from "@angular/common/http";

@NgModule({
  imports: [
    CommonModule,
    HttpClientModule
  ],
  declarations: [
    ],

   providers: [    
    AuthService,
    {
      provide: ErrorHandler, 
      useClass: HttpErrorHandler
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: RequestInterceptor,
      multi: true
    }
  ],
})
export class CoreModule { }
