import { InputBase } from "src/app/shared/form/service/input-base";

export class DatepickerInput extends InputBase<string> {
    controlType: string = "datepicker";
    type: string;
    validators: any[];
    constructor(options: {} = {}) {
        super(options);
        this.type = options["type"] || 'text';
        this.validators = options["validators"] || [];
    }
}