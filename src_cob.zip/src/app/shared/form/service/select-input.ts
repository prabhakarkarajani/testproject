import { InputBase } from "src/app/shared/form/service/input-base";

export class SelectInput extends InputBase<string> {
    controlType: string = "dropdown";
    options: { key: string, value: string }[] = [];
    type: string;
    validators: any[];
    constructor(options: {} = {}) {
        super(options);
        this.options = options['options'] || [];
        this.validators = options["validators"] || [];
    }
}