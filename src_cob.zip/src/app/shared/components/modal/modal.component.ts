import { Component, OnInit } from '@angular/core';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { InputBase } from "src/app/shared/form/service/input-base";
import { TextInput } from "src/app/shared/form/service/text-input.";
import { FormBuilder } from '@angular/forms';
import { Validators } from "@angular/forms";
import { ValidatorFn } from "@angular/forms";
import { AbstractControl } from "@angular/forms";
import { FormControl } from "@angular/forms";
import { SelectInput } from "src/app/shared/form/service/select-input";
@Component({
  selector: 'app-modal',
  templateUrl: './modal.component.html',
  styleUrls: ['./modal.component.scss']
})
export class ModalComponent implements OnInit {

  ngOnInit(): void {
    this.memberAndMedicaredata = this.getInputJSON();  
}

  closeResult: string;
  memberAndMedicaredata:InputBase<any>[] = [];
  
  
  constructor(private modalService: NgbModal) { }

  open(content) {

    
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title', size: 'lg' }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  getInputJSON() {
    
    let inputJSON: InputBase<any>[] = [
      new TextInput({
        key: 'FirstName',
        label: 'First name',
        value: '',
        order: 2,
        type: "text",
        validators: [Validators.required]
      }),

      new SelectInput({
        key: 'Choose Field Name',
        label: 'Choose Field Name',
        options:[
          { key: 'First Name', value: 'First Name' },
          { key: 'Last Name', value: 'Last Name' },
          { key: 'SSN', value: 'SSN' },
          { key: 'Middle Name', value: 'Middle Name' },
          { key: 'Suffix', value: 'Suffix' }
        ],
        order: 1,
        validators: [Validators.required]
      })
    ];

    return inputJSON.sort((a, b) => a.order - b.order);
  }

  // getMeicareJSON() {
  //   let selectOptions: [
  //     { key: 'firstname', value: 'First Name' },
  //     { key: 'lastname', value: 'Last Name' },
  //     { key: 'SSN', value: 'SSN' },
  //     { key: 'middlename', value: 'Middle Name' },
  //     { key: 'suffix', value: 'Suffix' }
  //   ]
  //   let inputJSON: InputBase<any>[] = [
  //     // new TextInput({
  //     //   key: 'firstName',
  //     //   label: 'First name',
  //     //   value: '',
  //     //   order: 2,
  //     //   type: "text",
  //     //   validators: [Validators.required]
  //     // }),
  //     new SelectInput({
  //       key: 'Choose Field Name',
  //       label: 'Choose Field Name',
  //       options: selectOptions,
  //       order: 0,
  //       validators: [Validators.required]
  //     }),
  //     new SelectInput({
  //       key: 'Choose Field Name',
  //       label: 'Choose Field Name',
  //       options:selectOptions,
  //       order: 1,
  //       validators: [Validators.required]
  //     })


  //   ];

  //   return inputJSON.sort((a, b) => a.order - b.order);
  // }

}
