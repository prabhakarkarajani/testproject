import React, {Component} from 'react';

class FlightSearch extends Component {
    render(){
        return(
            <div> FlightSearch </div>
        )
    }
}

export default FlightSearch;