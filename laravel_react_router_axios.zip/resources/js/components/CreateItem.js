// CreateItem.js

import React, {useState, useEffect} from 'react';
import axios from 'axios';
function CreateItem(props) {
    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(true)
  useEffect(() => {
    axios(
      'https://jsonplaceholder.typicode.com/todos',
    ).then(res => {
        console.log(res);
        console.log(res.data);
        setData(res.data);
        setLoading(false)
      });
       
  }, []);

  const clickHandler =(event) => {
      console.log(event);
  }
  
      return (
      <div className="container">
        <h1>Create An Item</h1>
        <form>
          <div className="row">
            <div className="col-md-6">
              <div className="form-group">
                <label>Item Name:</label>
                <input type="text" className="form-control" />
              </div>
            </div>
            </div>
            <div className="row">
              <div className="col-md-6">
                <div className="form-group">
                  <label>Item Price:</label>
                  <input type="text" className="form-control col-md-6" />
                </div>
              </div>
            </div><br />
            <div className="form-group">
              <button className="btn btn-primary">Add Item</button>
            </div>
        </form>
        <div>
        {loading ? 'Content loading...' :
        <ul>
      {data && data.map(item => (
        <li key={item.id} onClick={()=>clickHandler(item)} style={{padding: 15, fontSize: 15}}>
          {item.title}
        </li>
      ))}
        </ul> }
        </div>
  </div>
      )
    }
export default CreateItem;