import React, { useEffect, useState } from 'react';
import { Router, Route } from 'react-router-dom';
import  history  from '../helpers/history';
//import { connect } from 'react-redux';;
import routes from '../routes';
//import './style.scss';

function App(props) {
  const root = document.documentElement;
    return (
   
          <Router history={history}>
            <Route>{routes}</Route>
          </Router>
  );
}


export default App;
