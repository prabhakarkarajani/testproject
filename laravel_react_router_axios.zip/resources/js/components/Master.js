// Master.js

import React, {Component} from 'react';
import { Router, Route, Link } from 'react-router';

function Master(props){
  
    return (
    //   <div className="container">
    //     <nav className="navbar navbar-default">
    //       <div className="container-fluid">
    //         <div className="navbar-header">
    //           <a className="navbar-brand" href="#">AppDividend</a>
    //         </div>
    //         <ul className="nav navbar-nav">
    //           <li className="active"><a href="#">Home</a></li>
    //           <li><a href="#">Page 1</a></li>
    //           <li><a href="#">Page 2</a></li>
    //           <li><a href="#">Page 3</a></li>
    //         </ul>
    //       </div>
    //   </nav>
    //       <div>
    //           {props.children}
    //       </div>
    //   </div>
    <div>
                <Route path="/" render={(props) => (
                    <CurrencySidebar
                        currencies={this.state.currencies}
                        {...props}
                    />
                )}/>
                <Route exact path="/currency/:id" render={(props) => (
                    <Currency {...props}/>
                )}/>
            </div>
    )
  }

export default Master;