/* eslint-disable import/newline-after-import */
import { createBrowserHistory } from 'history';
const history = createBrowserHistory();

export default history;
