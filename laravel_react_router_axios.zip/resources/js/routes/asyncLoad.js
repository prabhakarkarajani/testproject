import Loader from 'components/Loader';
import Loadable from 'react-loadable';

export const Dashboard = Loadable({
  loader: () => import(/* webpackChunkName: "Dashboard" */ 'Dashboard'),
  loading: Loader
});

export const CatalogueSearchResults = Loadable({
  loader: () => import(/* webpackChunkName: "Catalogue Search" */ 'CatalogueSearch/CatalogueSearchResults'),
  loading: Loader
});


export const Library = Loadable({
  loader: () => import(/* webpackChunkName: "Library" */ 'Library'),
  loading: Loader
});

export const LandingPage = Loadable({
  loader: () => import(/* webpackChunkName: "Catalogue" */ 'ProductCatalogue/LandingPage'),
  loading: Loader
});

export const Products = Loadable({
  loader: () => import(/* webpackChunkName: "Products" */ 'ProductCatalogue/Products/Products'),
  loading: Loader
});
export const CreateProduct = Loadable({
  loader: () => import(/* webpackChunkName: "CreateProduct" */ 'ProductCatalogue/Products/CreateProduct'),
  loading: Loader
});
export const DemoForm = Loadable({
  loader: () => import(/* webpackChunkName: "DemoForm" */ 'ProductCatalogue/Products/DemoForm'),
  loading: Loader
});
export const QuickProduct = Loadable({
  loader: () => import(/* webpackChunkName: "QuickProduct" */ 'ProductCatalogue/Products/QuickProduct'),
  loading: Loader
});

export const Promotions = Loadable({
  loader: () => import(/* webpackChunkName: "Promotions" */ 'ProductCatalogue/Promotions/Promotions'),
  loading: Loader
});
export const CreatePromotion = Loadable({
  loader: () => import(/* webpackChunkName: "CreatePromotion" */ 'ProductCatalogue/Promotions/CreatePromotion'),
  loading: Loader
});
export const QuickPromotion = Loadable({
  loader: () => import(/* webpackChunkName: "QuickPromotion" */ 'ProductCatalogue/Promotions/QuickPromotion'),
  loading: Loader
});

export const Packages = Loadable({
  loader: () => import(/* webpackChunkName: "Packages" */ 'ProductCatalogue/Packages/Packages'),
  loading: Loader
});
export const CreatePackage = Loadable({
  loader: () => import(/* webpackChunkName: "CreatePackage" */ 'ProductCatalogue/Packages/CreatePackage'),
  loading: Loader
});
export const QuickPackage = Loadable({
  loader: () => import(/* webpackChunkName: "QuickPackage" */ 'ProductCatalogue/Packages/QuickPackage'),
  loading: Loader
});

/* CSR CATALOGIE */
export const PreQualification = Loadable({
  loader: () => import(/* webpackChunkName: "PreQualification" */ 'CSRCatalouge/PreQualification/PreQualification'),
  loading: Loader
});
export const CreateOffers = Loadable({
  loader: () => import(/* webpackChunkName: "CreateOffers" */ 'CSRCatalouge/Offers/CreateOffers'),
  loading: Loader
});
export const checkout = Loadable({
  loader: () => import(/* webpackChunkName: "checkout" */ 'CSRCatalouge/Checkout/checkout'),
  loading: Loader
});
export const OrderConfirmation = Loadable({
  loader: () => import(/* webpackChunkName: "OrderConfirmation" */ 'CSRCatalouge/OrderConfirmation/OrderConfirmation'),
  loading: Loader
});


