import React from 'react';
import { Route, Switch } from 'react-router-dom';
// import SignIn from 'SignIn';
// import { Dashboard, CatalogueSearchResults, Library, Products, LandingPage, CreateProduct, DemoForm, QuickProduct, Promotions, CreatePromotion, QuickPromotion, Packages, CreatePackage, QuickPackage, PreQualification, CreateOffers, checkout, OrderConfirmation } from './asyncLoad';
// import { PrivateRoute } from 'components/PrivateRoute';
// import { PublicRoute } from 'components/PublicRoute';
// import PageNotFound from 'components/PageNotFound';
// import CustomGrid from 'CustomGrid';
// import Configuration from 'Configuration';
// import OrderOverView from '../CSRCatalouge/OrderSummary/OrderSummary';
// import AccountOrders from '../CSRCatalouge/AccountOrders/AccountOrders';
import CreateItem from '../components/CreateItem';
const routes = (
  <Switch>
    {/* <PublicRoute path="/login" exact component={SignIn} />
    <PrivateRoute path="/catalogue" exact component={LandingPage} />
    <PrivateRoute exact path="/" component={Dashboard} hideLogo={false} />
    <PrivateRoute exact path="/dashboard" component={Dashboard} hideLogo={false} />
    <PrivateRoute exact path="/catalogue/products" component={Products} hideLogo module={'productManagement'} />
    <PrivateRoute path="/catalogue/createProduct" component={CreateProduct} hideLogo module={'productManagement'} />
    <PrivateRoute path="/catalogue/updateProduct" component={CreateProduct} hideLogo module={'productManagement'} />
    <PrivateRoute path="/catalogue/quickProduct" component={QuickProduct} hideLogo module={'productManagement'} />
    <PrivateRoute exact path="/catalogue/promotions" component={Promotions} hideLogo module={'productManagement'} />
    <PrivateRoute exact path="/catalogue/Packages" component={Packages} hideLogo module={'productManagement'} />
    <PrivateRoute exact path="/catalogue/createPackage" component={CreatePackage} hideLogo module={'productManagement'} />
    <PrivateRoute exact path="/catalogue/updatePackage" component={CreatePackage} hideLogo module={'productManagement'} />
    <PrivateRoute exact path="/catalogue/quickPackage" component={QuickPackage} hideLogo module={'productManagement'} />
    <PrivateRoute path="/catalogue/createPromotion" component={CreatePromotion} hideLogo module={'productManagement'} />
    <PrivateRoute path="/catalogue/updatePromotion" component={CreatePromotion} hideLogo module={'productManagement'} />
    <PrivateRoute path="/catalogue/quickPromotion" component={QuickPromotion} hideLogo module={'productManagement'} />
    <PrivateRoute exact path="/createAccount/prequalification" component={PreQualification} hideLogo module={'csr'} />
    <PrivateRoute path="/createAccount/offers/:accountId" component={CreateOffers} module={'csr'} hideLogo />
    <PrivateRoute exact path="/createAccount/checkout/:accountId" component={checkout} module={'csr'} hideLogo />
    <PrivateRoute exact path="/createAccount/OrderConfirmation/:accountId" component={OrderConfirmation} module={'csr'} />
    <Route path="/library" exact component={Library} />
    <PrivateRoute exact path="/orders" component={AccountOrders} module={'csr'} hideLogo />

    <PrivateRoute path="/orderSummary" exact component={OrderOverView} module={'csr'} hideLogo />

    <PrivateRoute exact path="/customgrid" component={CustomGrid} />
    <PrivateRoute path="/demoForm" component={DemoForm} hideLogo />
    <PrivateRoute path="/catalogueSearchResults" component={CatalogueSearchResults} />
    <PrivateRoute path="/configuration" component={Configuration} /> */}
    <Route exact path="/" component={CreateItem} />
  </Switch>
);

export default routes;
