import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DashboardComponent } from 'src/app/dashboard/dashboard.component';
import { AuthResolver } from './core/services/auth.resolver';
import { MainScreenModule } from './main-screen/main-screen.module';
import { CustomersModule } from './customers/customers.module'
import { TaskScreenComponent } from "src/app/task-screen/task-screen.component";
import { TestModule } from "src/app/test/test.module";
import {} from "";
const routes: Routes = [
   {
     path: '',
     component: DashboardComponent,
     resolve: {
       token: AuthResolver
     }
   },
  // {
  //   path: 'customers',
  //   loadChildren: () => CustomersModule
  // },
  {
    path: 'main-screen',
    loadChildren: () => MainScreenModule
  },
  // {
  //   path:'main-screen',
  //   component:MainscreenComponent
  // },
  {
    path:'task',
    component:TaskScreenComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
