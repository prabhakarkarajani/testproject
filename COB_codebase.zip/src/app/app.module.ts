import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { AppComponent } from './app.component';
import { CoreModule } from './core/core.module';
import { SharedModule } from './shared/shared.module';
//import { CustomersModule } from './customers/customers.module';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AuthResolver } from './core/services/auth.resolver';
import { AuthService } from './core/services/auth.service';
import { AppRoutingModule } from './app-routing.module';
// import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { HeaderComponent } from './shared/components/header/header.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TaskScreenComponent } from './task-screen/task-screen.component';
import { ErrorHandler } from "@angular/core";
import { HttpErrorHandler } from "src/app/core/errorHendler/HttpErrorHandler";
import { HTTP_INTERCEPTORS } from "@angular/common/http";
import { RequestInterceptor } from "src/app/core/services/request.interceptor";
import { TestModule } from "src/app/test/test.module";
@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    HeaderComponent,
    TaskScreenComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    CoreModule,
    SharedModule,
    TestModule,
   // AngularFontAwesomeModule,
   FormsModule, ReactiveFormsModule,
    NgbModule.forRoot()
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  providers: [AuthService, AuthResolver, {
      provide: ErrorHandler, 
      useClass: HttpErrorHandler
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: RequestInterceptor,
      multi: true
    }],
  bootstrap: [AppComponent]
})
export class AppModule { }
