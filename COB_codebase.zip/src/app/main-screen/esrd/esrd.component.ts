import { Component, OnInit, Input } from '@angular/core';
import { FormService } from "src/app/shared/form/service/form.service";
import { InputBase } from "src/app/shared/form/service/input-base";
import { FormBuilder, Validators, ValidatorFn, FormArray, FormGroup, FormControl } from "@angular/forms";
import { DatepickerInput } from "src/app/shared/form/service/datepicker-input";
import { TransplantESRDRule } from "src/app/rule-engine/transplant-esrd-rule";
import { RuleEngine } from "src/app/rule-engine/run-rule-engine";
import { InCenterESRDRule } from "src/app/rule-engine/in-center-esrd-rule";
import { DataSharingService } from "src/app/core/services/data-sharing.service";
import { HomeTraningESRDRule } from "src/app/rule-engine/home-training-esrd-rule";

@Component({
  selector: 'app-esrd',
  templateUrl: './esrd.component.html',
  styleUrls: ['./esrd.component.scss']
})
export class EsrdComponent implements OnInit {
  private isActive: boolean = false;
  inputJSON: InputBase<any>[] = [];
  coordinationFormGroup: FormGroup;
  @Input() potentialCorordinationDateList: any = [];

  /** claim treatement history input value for from,to */
  public claimTreatmentDate: string;
  public claimTreatmentEventType: string;
  payload: any = [];
  private getDate: string;
  private selectedValue: string;
  rules: Rule[] = [];
  constructor(private formService: FormService, private fb: FormBuilder, private dataSharingService: DataSharingService) { }

  ngOnInit() {
    console.log("iiiii")
    this.claimTreatmentDate;
    this.claimTreatmentEventType;
    this.claimTreatmentDate = "03/02/2016";
    this.claimTreatmentEventType = "In Center";
    this.coordinationFormGroup = this.formService.getFormBuilderArray(this.inputJSON);
    console.log(this.payload);
    this.potentialCorordinationDateList = this.dataSharingService.getTaskData.coordinationDates;

  }
  accordionShow() {
    this.isActive = !this.isActive;
  }
  get fbArray() {
    return this.coordinationFormGroup.get('fbArray') as FormArray;
  }


  /** coordination form input data */
  add(fromDate, toDate) {
    if (fromDate == undefined && toDate == undefined) {
      fromDate = "",
        toDate = ""
    }
    let dateControl = new DatepickerInput({
      key: 'From',
      label: 'From',
      value: fromDate || '',

      type: "text",
      validators: [Validators.required]
    });
    let dateControl1 = new DatepickerInput({
      key: 'To',
      label: 'To',
      value: toDate || '',

      type: "text",
      validators: [Validators.required]
    });
    this.fbArray.push(new FormControl(dateControl.value || '', { validators: dateControl["validators"] ? dateControl["validators"] : [], updateOn: 'blur' }));
    this.fbArray.push(new FormControl(dateControl1.value || '', { validators: dateControl1["validators"] ? dateControl1["validators"] : [], updateOn: 'blur' }));
    this.inputJSON.push(dateControl, dateControl1);

    //this.coordinationFormGroup = this.formService.getFormBuilderArray(this.inputJSON);
  }
  deleteCoordinationDates(i) {
    this.inputJSON.splice(i, 2);
    //this.coordinationFormGroup = this.formService.getFormBuilderArray(this.inputJSON);
    this.coordinationFormGroup.removeControl(i);
    this.coordinationFormGroup.removeControl(i + 1);
  }

  /** claim Treatement History list add fn */
  addToTreatmentHistory() {
    console.log(this.claimTreatmentDate, this.claimTreatmentEventType);
    this.payload.push({ claimTreatmentDate: this.claimTreatmentDate, claimTreatmentEventType: this.claimTreatmentEventType });
  }
  /** get esrd treatment history date and event type*/
  esrdTreatmentAction(getDate, selectedValue) {
    this.rules = [];
    if (getDate != undefined && selectedValue != undefined) {
      let treatementDate = getDate.month + '/' + getDate.day + '/' + getDate.year;
      this.payload.push({ claimTreatmentDate: treatementDate, claimTreatmentEventType: selectedValue });
      let input = {};
      input["treatment"] = treatementDate;
      if (selectedValue === "In Center") {
        input["event"] = "incenter";
        this.rules.push(new InCenterESRDRule(input, this.potentialCorordinationDateList, this.dataSharingService));
      } else if (selectedValue === "Home Training") {
        input["event"] = "home_training";
        this.rules.push(new HomeTraningESRDRule(input, this.potentialCorordinationDateList, this.dataSharingService));
      }

      // this.rules.push(new InCenterESRDRule({},{},{}));
      let potentialCorordinationDates = RuleEngine.run(this.rules);
      console.log(potentialCorordinationDates);
      this.potentialCorordinationDateList = this.dataSharingService.coordinationDates;

    }
  }

  getPotentialCoordinationPeriod(from, to) {
    let fromDate = from.split('/');
    let fDateObj = { 'year': +fromDate[2], 'month': +fromDate[0], 'day': +fromDate[1] };
    let toDate = to.split('/');
    let toDateObj = { 'year': +toDate[2], 'month': +toDate[0], 'day': +toDate[1] }
    this.add(fDateObj, toDateObj);
  }
}
