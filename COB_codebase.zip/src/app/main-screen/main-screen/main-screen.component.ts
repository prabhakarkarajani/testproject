import { Component, OnInit } from '@angular/core';
import { DataSharingService } from "src/app/core/services/data-sharing.service";
import { HttpConnectorService } from "src/app/shared/services/http-connector.service";
import { environment } from "src/environments/environment";

@Component({
  selector: 'app-mainscreen',
  templateUrl: './main-screen.component.html',
  styleUrls: ['./main-screen.component.scss']
})
export class MainScreenComponent implements OnInit {
  customer: any;
  repName: string;
  taskInfo: any;
  coordinationDates: any[];
  potentialCorordinationDateList:any = [];

  constructor(private dataSharedService: DataSharingService, private HttpConnector: HttpConnectorService) { }

  ngOnInit() {
    this.customer = this.dataSharedService.getTaskData["memberdetails"];
    this.taskInfo = this.dataSharedService.getTaskData["takDetails"];
    this.repName = this.dataSharedService.getTaskData["repName"]; 
    this.dataSharedService.coordinationDates = this.dataSharedService.getTaskData["coordinationDates"];   
  }

  saveAndGetNewTask() {
    this.dataSharedService.repName = this.repName;
    this.dataSharedService.getTaskData["coordinationDates"] = this.dataSharedService.coordinationDates;
    this.dataSharedService.getTaskData["repName"] = this.repName
    let request = { "id": this.dataSharedService.id, "test_sting": JSON.stringify(this.dataSharedService.getTaskData) };
    this.HttpConnector.postRequest(environment.SET_TASK, request).subscribe(response => {
      this.dataSharedService.getTaskData = JSON.parse(response.test_sting);
      this.customer = this.dataSharedService.getTaskData["memberdetails"];
      this.dataSharedService.coordinationDates = this.dataSharedService.getTaskData["coordinationDates"];
      this.coordinationDates = this.dataSharedService.coordinationDates;
      this.potentialCorordinationDateList = this.dataSharedService.getTaskData["coordinationDates"];
      this.repName = this.dataSharedService.getTaskData["repName"];  
    });
  }

  saveTask() {
    this.dataSharedService.repName = this.repName;
    this.dataSharedService.getTaskData["coordinationDates"] = this.dataSharedService.coordinationDates;
    this.dataSharedService.getTaskData["repName"] = this.repName
    let request = { "id": this.dataSharedService.id, "test_sting": JSON.stringify(this.dataSharedService.getTaskData) };
    this.HttpConnector.postRequest(environment.UPDATE_TASK, request).subscribe(response => {
      //this.dataSharedService.getTaskData = response;
      //this.customer = this.dataSharedService.getTaskData["memberdetails"];
      console.log(response)
    });
  }

  saveData(obj: any) {
    obj.forEach(element => {
      this.dataSharedService.getTaskData["memberdetails"][element.key] = element.value
      this.customer[element.key] = element.value;
    });
  }

}
