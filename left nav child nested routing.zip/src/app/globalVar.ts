export class GlobalVar {
    public memberInfo: boolean = false;
}