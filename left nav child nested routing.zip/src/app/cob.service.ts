import { Injectable} from '@angular/core';

import { Observable, of} from 'rxjs';

import { DATA} from './fake_data';
import { NAVITEMS} from './navigation';


@Injectable({providedIn: 'root'})
export class CobService {
    constructor(){}

        getData():Observable<any> {
            return of(DATA);
        }
        
        getNavItems():Observable<any> {
            return of(NAVITEMS);
        }
    
}