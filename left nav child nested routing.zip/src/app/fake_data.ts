export const DATA = {
	"CaseSeq" : 111111,
	"OptyId" : -1,
	"ClientPartSeq" : 17,
	"ClientId" : "773",
	"ClientName" : "HarvardPilgrim",
	"CustMemberId" : "HPP123456789",
	"ExpectedOptyAmt" : 0.0000,
	"NormalizedProbability" : 7949.00000,
	"ExecutionPt" : "02",
	"EffDte" : "2018-04-05",
	"TermDte" : "2019-04-05",
	"CaseAddedDate" : "2018-04-05",
	"StatusIdEligibility" : 10,
	"CaseStatusSeq" : 0,
	"CASE_STATUS" : [{
			"CaseStatusSeq" : 0,
			"CaseStatusName" : "Ready"
		}
	],
	"CASE_REVIEW_REASON" : [{
			"CaseReviewReasonSeq" : 1432593,
			"CaseSeq" : 111111,
			"ReviewReasonId" : 1,
			"REVIEW_REASON" : [{
					"ReviewReasonId" : 1,
					"ReviewReasonName" : "Age",
					"REVIEW_REASON_PROJECTS" : [{}
					]
				}
			]
		}, {
			"CaseReviewReasonSeq" : 1407375,
			"CaseSeq" : 111111,
			"ReviewReasonId" : 3,
			"REVIEW_REASON" : [{
					"ReviewReasonId" : 3,
					"ReviewReasonName" : "ESRD",
					"REVIEW_REASON_PROJECTS" : [{}
					]
				}
			]
		}
	],
	"CLIENT_ELIGIBILITY" : [{
			"ClientEligibilitySeq" : 20,
			"ClientPartSeq" : 17,
			"RRE" : "11048",
			"MedicareAcct5Digits" : "98765",
			"UpdatePrimacyInd" : false,
			"AllowEmploymentVerificationInd" : true
		}
	],
	"CASE_PROCESS_STATUS" : [{
			"StatusId" : 0,
			"StatusName" : "Ready"
		}
	],
	"VERIFICATION" : [{
			"VerificationSeq" : 1868488,
			"InquiryTypeId" : 2,
			"CaseSeq" : 111111,
			"INQUIRY_TYPE" : [{
					"InquiryTypeId" : 2,
					"InquiryClassId" : 1,
					"InquiryTypeName" : "ESRD_Rep",
					"InquiryTypeDesc" : "ESRD_Rep",
					"InquiryTypeActiveInd" : true,
					"INQUIRY_CLASS" : [{
							"InquiryClassId" : 1,
							"InquiryClassName" : "Class_Name",
							"InquiryClassDesc" : "Class Desc",
							"InquiryClassActiveInd" : true,
							"EffectiveDte" : "2017-05-03",
							"TermDte" : "2018-05-03"
						}
					]
				}
			]
		}
	],
	"CASE_MEMBER" : [{
			"CaseMemberSeq" : 1842909,
			"CaseSeq" : 111111,
			"MemberGuid" : "ADA4AAB4-78A4-4B52-B70C-CFC83FDC300B",
			"SSN" : "015269895",
			"FirstNm" : "JANE A",
			"LastNm" : "DOE",
			"Gender" : "F",
			"DOB" : "1948-02-08",
			"PlanName" : "",
			"GroupId" : "074082",
			"GroupName" : "GROUP ABC 123",
			"RelationshipCd" : "SUB",
			"MedicareEntitlementAgeInd" : false,
			"MedicareEntitlementAgeIndSuspected" : true,
			"MedicareEntitlementDisabilityInd" : false,
			"MEDICARE_ESRD_TREATMENT" : [{
					"MedicareEsrdTreatmentSeq" : 2071,
					"CaseMemberSeq" : 1842909,
					"MedicareEsrdTreatmentTypeSeq" : 2,
					"TreatmentDate" : "2017-11-22",
					"InfoSource" : "Claim",
					"MedicareValueInd" : false,
					"MEDICARE_ESRD_TREATMENT_TYPE" : [{
							"MedicareEsrdTreatmentTypeSeq" : 2,
							"TreatmentTypeName" : "In_Center"
						}
					]
				}
			],
			"MEDICARE_COVERAGE" : [{
					"MedicareCoverageSeq" : 75190,
					"CaseMemberSeq" : 1961949,
					"MedicarePartCode" : "A",
					"EffDte" : "2017-11-01",
					"InfoSource" : "COB Tracker"
				}, {
					"MedicareCoverageSeq" : 75343,
					"CaseMemberSeq" : 1961949,
					"MedicarePartCode" : "B",
					"EffDte" : "2017-11-01",
					"InfoSource" : "COB Tracker"
				}
			],
			"MEMBER_ADDRESS" : [{
					"MemberAddressSeq" : 1585954,
					"CustMemberId" : "HPP60906000",
					"CaseMemberSeq" : 1842909,
					"AddressType" : "HOME      ",
					"MemberAddressGUID" : "BC0CFC8B-F4F4-4312-A97D-8B5078BAA2BA",
					"Address1" : "731 Arbor Way",
					"City" : "Blue Bell",
					"StateCd" : "PA"
				}
			],
			"MEMBER_ADDRESSES_EXTRA" : [{
					"MemberAddressesExtraSeq" : 1719056,
					"CaseMemberSeq" : 1842909,
					"Address1" : "735 ARBOR WAY",
					"Address2" : "",
					"Address3" : "",
					"City" : "BLUE BELL",
					"StateCd" : "PA",
					"ZipCd" : "19191",
					"InfoSource" : "COB Tracker",
					"MedicareValueInd" : false,
					"FirstDateCalc" : "1900-01-02",
					"LastDateCalc" : "2014-12-21",
					"Occurrences" : 1,
					"OccurrencesDistinct" : 1
				}
			],
			"MEMBER_INFO_EXTRA" : [{
					"MemberInfoExtraSeq" : 9555770,
					"MemberInfoTypeSeq" : 11,
					"CaseMemberSeq" : 1842909,
					"InfoValue" : "DEP",
					"InfoSource" : "COB Tracker",
					"FirstDateCalc" : "1900-01-02",
					"LastDateCalc" : "1900-01-02",
					"Occurrences" : 9,
					"OccurrencesDistinct" : 1,
					"MEMBER_INFO_TYPE" : [{
							"MemberInfoTypeSeq" : 11,
							"InfoTypeName" : "RelationshipCd"
						}
					]
				}, {
					"MemberInfoExtraSeq" : 9555771,
					"MemberInfoTypeSeq" : 11,
					"CaseMemberSeq" : 1842909,
					"InfoValue" : "SUB",
					"InfoSource" : "COB Tracker",
					"FirstDateCalc" : "2014-12-21",
					"LastDateCalc" : "2014-12-21",
					"Occurrences" : 1,
					"OccurrencesDistinct" : 1,
					"MEMBER_INFO_TYPE" : [{
							"MemberInfoTypeSeq" : 11,
							"InfoTypeName" : "RelationshipCd"
						}
					]
				}, {
					"MemberInfoExtraSeq" : 9589892,
					"MemberInfoTypeSeq" : 1,
					"CaseMemberSeq" : 1842909,
					"InfoValue" : "JANE A",
					"InfoSource" : "COB Tracker",
					"FirstDateCalc" : "1900-01-02",
					"LastDateCalc" : "2014-12-21",
					"Occurrences" : 10,
					"OccurrencesDistinct" : 1,
					"MEMBER_INFO_TYPE" : [{
							"MemberInfoTypeSeq" : 1,
							"InfoTypeName" : "FirstNm"
						}
					]
				}, {
					"MemberInfoExtraSeq" : 9705456,
					"MemberInfoTypeSeq" : 3,
					"CaseMemberSeq" : 1842909,
					"InfoValue" : "DOE",
					"InfoSource" : "COB Tracker",
					"FirstDateCalc" : "1900-01-02",
					"LastDateCalc" : "2014-12-21",
					"Occurrences" : 10,
					"OccurrencesDistinct" : 1,
					"MEMBER_INFO_TYPE" : [{
							"MemberInfoTypeSeq" : 3,
							"InfoTypeName" : "LastNm"
						}
					]
				}, {
					"MemberInfoExtraSeq" : 9797044,
					"MemberInfoTypeSeq" : 5,
					"CaseMemberSeq" : 1842909,
					"InfoValue" : "015269895",
					"InfoSource" : "COB Tracker",
					"FirstDateCalc" : "1900-01-02",
					"LastDateCalc" : "2014-12-21",
					"Occurrences" : 10,
					"OccurrencesDistinct" : 1,
					"MEMBER_INFO_TYPE" : [{
							"MemberInfoTypeSeq" : 5,
							"InfoTypeName" : "SSN"
						}
					]
				}, {
					"MemberInfoExtraSeq" : 9887727,
					"MemberInfoTypeSeq" : 6,
					"CaseMemberSeq" : 1842909,
					"InfoValue" : "1948-02-08",
					"InfoSource" : "COB Tracker",
					"FirstDateCalc" : "1900-01-02",
					"LastDateCalc" : "2014-12-21",
					"Occurrences" : 10,
					"OccurrencesDistinct" : 1,
					"MEMBER_INFO_TYPE" : [{
							"MemberInfoTypeSeq" : 6,
							"InfoTypeName" : "DOB"
						}
					]
				}
			]
		}
	]
}
