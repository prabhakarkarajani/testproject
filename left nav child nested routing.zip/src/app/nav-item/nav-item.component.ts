import { Component, OnInit,Input } from '@angular/core';
import {  Router  } from '@angular/router';
import { GlobalVar} from '../globalVar';

@Component({
  selector: 'app-nav-item',
  templateUrl: './nav-item.component.html',
  styleUrls: ['./nav-item.component.css'],
  providers: [ GlobalVar ]
})
export class NavItemComponent implements OnInit {

  constructor( private globals: GlobalVar, public router:Router) { }

  ngOnInit() {
    console.log('child',this.child);
  }
  @Input() child:any;

  navigateTo(data):void{
    console.log(data.component)
       this.router.navigate(["/eligibility/"+data.component])
  }

}
