import { Component } from '@angular/core';
import {  Router  } from '@angular/router';

import { CobService } from './cob.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'my-app';
  public data;
  constructor(private cobService: CobService, private router:Router ) { }
  ngOnInit() {
    this.getData();
  
  }
 

  getData(): void {
    this.cobService.getData()
    .subscribe(res => this.data = res);

  }

  public redirectPage(){
    let userData = this.data;
    console.log('user data',userData)
/**
 * check the ssn and dob value is empty or not
 * if empty  redirect to data collection
 * it !empty redirect to eligibilty
 */
    if((userData.CASE_MEMBER[0].SSN !== null && userData.CASE_MEMBER[0].DOB !== null) || (userData.CASE_MEMBER[0].SSN  !== '' && (userData.CASE_MEMBER[0].DON !== ''))){
      this.router.navigate(["eligibility"])
    }else {
      this.router.navigate(["dataCollection"])
    }
    
    
  }
}
