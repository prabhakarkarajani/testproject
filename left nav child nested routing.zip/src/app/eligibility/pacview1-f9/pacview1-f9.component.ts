import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pacview1-f9',
  templateUrl: './pacview1-f9.component.html',
  styleUrls: ['./pacview1-f9.component.css']
})
export class PACview1F9Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
