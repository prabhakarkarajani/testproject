import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PACview1F9Component } from './pacview1-f9.component';

describe('PACview1F9Component', () => {
  let component: PACview1F9Component;
  let fixture: ComponentFixture<PACview1F9Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PACview1F9Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PACview1F9Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
