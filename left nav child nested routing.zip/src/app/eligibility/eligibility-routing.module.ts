import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LayoutComponent } from './layout.component';
import { CSDImemberinformationComponent } from './csdimemberinformation/csdimemberinformation.component';
import { CSDIplaninformationComponent}from "./csdiplaninformation/csdiplaninformation.component";

const routes: Routes = [

    {
        path: '', component: LayoutComponent, children: [
             { path: '', redirectTo: '/eligibility/csdimemberinformation', pathMatch: 'full' },
            { path: 'csdimemberinformation', component: CSDImemberinformationComponent },
            {path:'csdiplaninformation',component:CSDIplaninformationComponent}
        ]
    }


];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class EligibiltyRoutingModule { }