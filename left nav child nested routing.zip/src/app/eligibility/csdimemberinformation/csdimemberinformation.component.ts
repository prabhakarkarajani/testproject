import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-csdimemberinformation',
  templateUrl: './csdimemberinformation.component.html',
  styleUrls: ['./csdimemberinformation.component.css']
})
export class CSDImemberinformationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
