import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CSDImemberinformationComponent } from './csdimemberinformation.component';

describe('CSDImemberinformationComponent', () => {
  let component: CSDImemberinformationComponent;
  let fixture: ComponentFixture<CSDImemberinformationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CSDImemberinformationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CSDImemberinformationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
