import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-explana',
  templateUrl: './explana.component.html',
  styleUrls: ['./explana.component.css']
})
export class ExplanaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
