import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExplanaComponent } from './explana.component';

describe('ExplanaComponent', () => {
  let component: ExplanaComponent;
  let fixture: ComponentFixture<ExplanaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExplanaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExplanaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
