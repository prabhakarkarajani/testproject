import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DCSsubscriberinformationComponent } from './dcssubscriberinformation.component';

describe('DCSsubscriberinformationComponent', () => {
  let component: DCSsubscriberinformationComponent;
  let fixture: ComponentFixture<DCSsubscriberinformationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DCSsubscriberinformationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DCSsubscriberinformationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
