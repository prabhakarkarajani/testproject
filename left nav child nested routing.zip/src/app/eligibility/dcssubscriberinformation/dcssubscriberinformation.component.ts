import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dcssubscriberinformation',
  templateUrl: './dcssubscriberinformation.component.html',
  styleUrls: ['./dcssubscriberinformation.component.css']
})
export class DCSsubscriberinformationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
