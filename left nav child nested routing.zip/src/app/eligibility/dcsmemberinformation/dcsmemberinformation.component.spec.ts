import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DCSmemberinformationComponent } from './dcsmemberinformation.component';

describe('DCSmemberinformationComponent', () => {
  let component: DCSmemberinformationComponent;
  let fixture: ComponentFixture<DCSmemberinformationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DCSmemberinformationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DCSmemberinformationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
