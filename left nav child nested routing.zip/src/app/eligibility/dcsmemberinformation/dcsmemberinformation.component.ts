import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dcsmemberinformation',
  templateUrl: './dcsmemberinformation.component.html',
  styleUrls: ['./dcsmemberinformation.component.css']
})
export class DCSmemberinformationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
