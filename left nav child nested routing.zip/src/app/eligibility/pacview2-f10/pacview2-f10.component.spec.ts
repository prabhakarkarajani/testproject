import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PACview2F10Component } from './pacview2-f10.component';

describe('PACview2F10Component', () => {
  let component: PACview2F10Component;
  let fixture: ComponentFixture<PACview2F10Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PACview2F10Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PACview2F10Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
