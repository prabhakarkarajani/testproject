import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pacview2-f10',
  templateUrl: './pacview2-f10.component.html',
  styleUrls: ['./pacview2-f10.component.css']
})
export class PACview2F10Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
