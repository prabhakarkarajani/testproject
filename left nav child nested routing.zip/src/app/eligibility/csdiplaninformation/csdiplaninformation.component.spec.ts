import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CSDIplaninformationComponent } from './csdiplaninformation.component';

describe('CSDIplaninformationComponent', () => {
  let component: CSDIplaninformationComponent;
  let fixture: ComponentFixture<CSDIplaninformationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CSDIplaninformationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CSDIplaninformationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
