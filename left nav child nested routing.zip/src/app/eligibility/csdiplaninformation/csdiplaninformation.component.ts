import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-csdiplaninformation',
  templateUrl: './csdiplaninformation.component.html',
  styleUrls: ['./csdiplaninformation.component.css']
})
export class CSDIplaninformationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
