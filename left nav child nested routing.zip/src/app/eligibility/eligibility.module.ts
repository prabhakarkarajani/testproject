//import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { EligibiltyRoutingModule } from './eligibility-routing.module';
import { LayoutComponent } from './layout.component';
import { CSDImemberinformationComponent } from './csdimemberinformation/csdimemberinformation.component';
import { CSDIplaninformationComponent } from './csdiplaninformation/csdiplaninformation.component';
import { ClaimssummaryComponent } from './claimssummary/claimssummary.component';
import { DCSmemberinformationComponent } from './dcsmemberinformation/dcsmemberinformation.component';
import { DCSsubscriberinformationComponent } from './dcssubscriberinformation/dcssubscriberinformation.component';
import { ExplanaComponent } from './explana/explana.component';
import { ExplanationofbenfitsComponent } from './explanationofbenfits/explanationofbenfits.component';
import { PACview1F9Component } from './pacview1-f9/pacview1-f9.component';
import { PACview2F10Component } from './pacview2-f10/pacview2-f10.component';
import { SummaryprocessscreenF11Component } from './summaryprocessscreen-f11/summaryprocessscreen-f11.component';
import { LeftNavComponent } from "../left-nav/left-nav.component";
import { NavItemComponent } from '../nav-item/nav-item.component';
import { CommonModule } from '@angular/common';

@NgModule({
    imports: [
        //BrowserModule,
        CommonModule,
        EligibiltyRoutingModule

    ],
    declarations: [
        LayoutComponent,
        CSDImemberinformationComponent,
        CSDIplaninformationComponent,
        ClaimssummaryComponent,
        DCSmemberinformationComponent,
        DCSsubscriberinformationComponent,
        ExplanaComponent,
        ExplanationofbenfitsComponent,
        PACview1F9Component,
        PACview2F10Component,
        SummaryprocessscreenF11Component,
        LeftNavComponent,
        NavItemComponent
    ],
    providers: [],

})
export class EligibiltyModule { }