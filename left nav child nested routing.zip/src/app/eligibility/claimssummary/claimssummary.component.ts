import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-claimssummary',
  templateUrl: './claimssummary.component.html',
  styleUrls: ['./claimssummary.component.css']
})
export class ClaimssummaryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
