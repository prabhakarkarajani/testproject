import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClaimssummaryComponent } from './claimssummary.component';

describe('ClaimssummaryComponent', () => {
  let component: ClaimssummaryComponent;
  let fixture: ComponentFixture<ClaimssummaryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClaimssummaryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClaimssummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
