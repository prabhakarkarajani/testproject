import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-explanationofbenfits',
  templateUrl: './explanationofbenfits.component.html',
  styleUrls: ['./explanationofbenfits.component.css']
})
export class ExplanationofbenfitsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
