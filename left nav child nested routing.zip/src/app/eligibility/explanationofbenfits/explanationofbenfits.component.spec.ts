import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExplanationofbenfitsComponent } from './explanationofbenfits.component';

describe('ExplanationofbenfitsComponent', () => {
  let component: ExplanationofbenfitsComponent;
  let fixture: ComponentFixture<ExplanationofbenfitsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExplanationofbenfitsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExplanationofbenfitsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
