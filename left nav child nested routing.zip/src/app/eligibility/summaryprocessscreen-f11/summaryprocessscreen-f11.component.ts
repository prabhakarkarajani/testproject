import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-summaryprocessscreen-f11',
  templateUrl: './summaryprocessscreen-f11.component.html',
  styleUrls: ['./summaryprocessscreen-f11.component.css']
})
export class SummaryprocessscreenF11Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
