import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SummaryprocessscreenF11Component } from './summaryprocessscreen-f11.component';

describe('SummaryprocessscreenF11Component', () => {
  let component: SummaryprocessscreenF11Component;
  let fixture: ComponentFixture<SummaryprocessscreenF11Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SummaryprocessscreenF11Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SummaryprocessscreenF11Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
