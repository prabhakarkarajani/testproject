export const NAVITEMS = [
  {
    "label": "Claims Sub/Dep Inquiry",
    "child": [
      {
        "label": "Member Information",
       
        "url":"csdimemberinformation"
        
      },
      {
        "label": "Plan Information",
       
        "url":"csdiplaninformation"
      }
    ]
  },
  {
    "label": "Claims Summary (Patient Number (on screen)) "
  },
  {
    "label": "Detailed Claims Summary",
    "child": [
      {
        "label": "Member Information"
      },
      {
        "label": "Subscriber Information"
      }
    ]
  },
  {
    "label": "Explanation of Benefits (S)"
  },
  {
    "label": "PAC View1 (F9)"
  },
  {
    "label": "PAC View 2 (F10)"
  },
  {
    "label": "Summary Process Screen (F11)"
  },
  {
    "label": "Professional Provider inquiry Screen (15)"
  },
  {
    "label": "Limited Liability Selection (26)",
    "child": [
      {
        "label": "Medicare Information"
      }
    ]
  },
  {
    "label": "Group Information (14)"
  },
  {
    "label": "Eligibility INQ (EA)",
    "child": [
      {
        "label": "Plan Information"
      }
    ]
  },
  {
    "label": "General Info (GA)",
    "child": [
      {
        "label": "Plan Information"
      }
    ]
  },
  {
    "label": "Group Address/ID Cards INQ (GF)",
    "child": [
      {
        "label": "Employer Information"
      }
    ]
  },
  {
    "label": "Group Contract/Billing (CA)",
    "child": [
      {
        "label": "Plan Information"
      }
    ]
  },
  {
    "label": "Member/Contract Inquiry Screen (M2)",
    "child": [
      {
        "label": "Member Information"
      },
      {
        "label": "Other Insurance Information"
      }
    ]
  }
]