import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-data-collection',
  templateUrl: './data-collection.component.html',
  styleUrls: ['./data-collection.component.css']
})
export class DataCollectionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
