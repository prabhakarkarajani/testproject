import { Component, OnInit } from '@angular/core';


import { GlobalVar} from '../globalVar';
@Component({
  selector: 'app-right-container',
  templateUrl: './right-container.component.html',
  styleUrls: ['./right-container.component.css'],
  providers: [ GlobalVar ]
})
export class RightContainerComponent implements OnInit {

  constructor(private globals: GlobalVar) { }

  ngOnInit() {
    console.log( this.globals.memberInfo);
  }


}
