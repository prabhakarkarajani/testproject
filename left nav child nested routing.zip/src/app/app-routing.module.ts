import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { DataCollectionComponent } from './data-collection/data-collection.component';


const routes: Routes = [
   { path: '', redirectTo: 'eligibility', pathMatch: 'full' },
  { path: 'dataCollection', component: DataCollectionComponent },
  { path: 'eligibility', loadChildren: './eligibility/eligibility.module#EligibiltyModule'  }
];
@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
  exports: [RouterModule],
  declarations: []
})
export class AppRoutingModule { }
