import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './/app-routing.module';
import { DataCollectionComponent } from './data-collection/data-collection.component';
import { HeaderComponent } from './header/header.component';
import { RightContainerComponent } from './right-container/right-container.component';



@NgModule({
  declarations: [
    AppComponent,
    DataCollectionComponent,

    HeaderComponent,

    RightContainerComponent

  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule
  ],
  providers: [{ provide: LocationStrategy, useClass: HashLocationStrategy }],
  bootstrap: [AppComponent]
})
export class AppModule { }
