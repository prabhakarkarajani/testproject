import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ModalComponent } from './components/modal/modal.component';
import { FormComponent } from './form/form.component';
import {ReactiveFormsModule} from '@angular/forms';
import { InputElementsFactoryComponent } from './form/input-elements-factory/input-elements-factory.component';


@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule
  ],
  declarations: [ModalComponent, FormComponent, InputElementsFactoryComponent],
  exports:[FormComponent]
})
export class SharedModule { }
