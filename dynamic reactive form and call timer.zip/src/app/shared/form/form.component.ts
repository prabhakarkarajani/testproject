import { Component, OnInit } from '@angular/core';
import { FormService } from "src/app/shared/form/service/form.service";
import { InputBase } from "src/app/shared/form/service/input-base";
import { FormBuilder } from "@angular/forms";
import { FormArray } from "@angular/forms";
import { TextInput } from "src/app/shared/form/service/text-input.";

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css'],
  providers: [FormService]
})
export class FormComponent implements OnInit {
  inputJSON: InputBase<any>[] = [];
  formGroupObj: any;
  constructor(private formService: FormService, private fb: FormBuilder) {
    this.inputJSON = this.formService.getInputJSON();
    this.formGroupObj = this.formService.getFormBuilderArray();
    this.formGroupObj = this.formService.getFormBuilderArray();
    
  }

  ngOnInit() {

  }

  get fbArray() {
    return this.formGroupObj.get('fbArray') as FormArray;
  }


  addToArray() {
    this.inputJSON.push(new TextInput({
      key: 'age',
      label: 'Age',
      value: '11',
      order: 0,
      type: "number"
    }));
    this.fbArray.push(this.fb.control('11'));
    console.log("===>", this.formGroupObj.value)
  }

  submit() {

  }

}
