import { Injectable } from '@angular/core';
import { InputBase } from "src/app/shared/form/service/input-base";
import { TextInput } from "src/app/shared/form/service/text-input.";
import { FormBuilder } from '@angular/forms';
import { Validators } from "@angular/forms";
import { ValidatorFn } from "@angular/forms";
import { AbstractControl } from "@angular/forms";
import { FormControl } from "@angular/forms";

@Injectable({
  providedIn: 'root'
})
export class FormService {
min:number = 20;
max:number = 60;
  constructor(private fb: FormBuilder) { }

  getFormBuilderArray() {
    let formObject: InputBase<any>[] = this.getInputJSON();
    let formBilderArray: any[] = [];
    let formGroup;
    formObject.forEach(elemnt => {
      formBilderArray.push(new FormControl(elemnt.value || '', { validators: elemnt["validators"]?elemnt["validators"]:[], updateOn: 'blur' }));
    })
     formGroup = this.fb.group({
      fbArray:this.fb.array(formBilderArray) 
     })
    return formGroup;
  }

  getInputJSON() {
    let inputJSON: InputBase<any>[] = [
      new TextInput({
        key: 'firstName',
        label: 'First name',
        value: 'Bombasto',
        order: 0,
        type: "text",
        validators:[Validators.required]
      }),
      new TextInput({
        key: 'lastName',
        label: 'Last name',
        value: 'xyz',
        order: 1,
        type: "email",
        validators:[Validators.required,Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')]
      
    }),
     new TextInput({
        key: 'age',
        label: 'age',
        value: '',
        order: 2,
        type: "number",
        validators:[Validators.required,this.ageRangeValidator(this.min, this.max)]
    })


    ];

    return inputJSON;
  }

   ageRangeValidator(min: number, max: number): ValidatorFn {
    return (control: AbstractControl): { [key: string]: boolean } | null => {
      let value = +control.value; 
        if (value > 0 && (value < min || value > max)) {
            control.setValue(0);
            console.log('true')
            return { 'ageRange': true };
        }
        return null;
    };
}

}
