export class InputBase<T> {
    value: T;
    key: string;
    label: string;
    order: number;
    inputType: string;
    constructor(options: {
        value?: T,
        key?: string,
        label?: string,
        order?: number,
        inputType?: string
    } = {}) {
        this.value = options.value;
        this.key = options.key || '';
        this.label = options.label || '';
        this.order = options.order === undefined ? 1 : options.order;
        this.inputType = options.inputType || '';
    }
}