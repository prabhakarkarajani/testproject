import { InputBase } from "src/app/shared/form/service/input-base";

export class TextInput extends InputBase<string> {
    inputType:string = "input";
    type: string;
    validators:any[];
    constructor(options: {} = {}) {
        super(options);
        this.type = options["type"] || 'text';
        this.validators = options["validators"] || [];
    }
}