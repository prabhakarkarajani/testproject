import { Component, OnInit } from '@angular/core';
import { DataSharingService } from "src/app/core/services/data-sharing.service";

@Component({
  selector: 'app-input',
  templateUrl: './input.component.html',
  styleUrls: ['./input.component.css']
})
export class InputComponent implements OnInit {

  constructor(private dataSharingService:DataSharingService) { }
data:string;
  ngOnInit() {
    this.data = this.dataSharingService.test; 
  }

}
