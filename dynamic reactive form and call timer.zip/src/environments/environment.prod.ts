export const environment = {
  production: true,
  AUTH_URL:'/assets/models/auth.json'
};
