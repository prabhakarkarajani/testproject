import React, {Component} from 'react';

class Footer extends Component {
    render(){
        return(
            <div className="Footer">copyrights resereved by Virtusa </div>
        )
    }
}

export default Footer;