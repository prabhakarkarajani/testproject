import React,{Component} from 'react';
import PropTypes from 'prop-types'; //npm install prop-types

class Greeting extends Component{
    constructor(props){
        super(props);
    }
    render(){
        return(
            <div className="Dashboard">Welcom {this.props.name} </div>
        )
    }
}

export default Greeting;

//define default prop values here

Greeting.defaultProps = {
    name: 'prabhakar'
}

//make sure we have all the props

Greeting.PropTypes = {
    name:PropTypes.string.isRequired
}