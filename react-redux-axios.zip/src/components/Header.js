import React, {Component} from 'react';
import {Link} from 'react-router-dom';
class Header extends Component {
    constructor(props){
        super(props)
    }
    render(){
        return(
            <div className="Header"> 
            <Link to='/'>Home</Link>
            <Link to='/About'>About</Link>
            <Link to="/Contact">contact us</Link>
            </div>
        )
    }
}

export default Header;