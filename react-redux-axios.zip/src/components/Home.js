import React, { Component } from "react";
import { connect } from "react-redux";
import reducer from '../reducers';
import {fetchPosts}from '../actions/postAction';
 class Home extends Component {
  constructor(props) {
    super(props);
  }
  componentDidMount () {
   
  }
  render() {
    const j = Object.values(this.props.posts.post);
    return (
      <div>
        Home page {this.props.name}
       <br/>
       {j.map((item,index) => 
               <div className="divBlock" key={index}>
               <img src={item.thumbnailUrl} />
{/*                
                  <span>{item.title} </span>
                   */}
               </div>
           )}
        </div>
    );
  }
}

const mapStateToProps = state => ({
  posts: state.posts
  
});

const mapDispatchToProps = dispatch => {
 
  return fetchPosts({
    posts : () => dispatch({
      type : 'FETCH_POSTS_RECEVIED'
      
    })
  })
}
export default connect(mapStateToProps,mapDispatchToProps)(Home);
