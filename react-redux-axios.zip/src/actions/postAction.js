import Axios from 'axios';
const apiUrl = 'https://jsonplaceholder.typicode.com/photos';//'https://jsonplaceholder.typicode.com/posts';
export function fetchPosts(){
  return function(dispatch){
    Axios.get(apiUrl)
    .then(res =>{// Dispatch another action // to consume data
                dispatch({type:'FETCH_POSTS_RECEVIED',payload:res.data}) 
                
              }).catch(error=>{
               // dispatch({type:'FETCH_POSTS_REJECTED',payload:res.data})   
                throw(error);
              })
  }
}



  