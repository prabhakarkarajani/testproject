import React, { Component } from 'react';
import Header from './components/Header';
import {Route} from 'react-router-dom';
//importing the pages
import Home from './components/Home';
import About from './components/About';
import Contact from './components/Contact'
import Footer from './Footer';
import './App.css';
import Display from './components/Display';

export default class App extends Component {
  render() {
    return (
      <div className="App">
      <Header />
      <Route exact path='/' component={()=><Home name="prabhakar"/>}/>
      <Route path='/About'  component={About} />
      <Route path='/Contact' component={Contact}/>
      {/* <Display/> */}
            <Footer/>
      </div>
    );
  }
}

