const initState = {
  fetching: false,
  fetched: false,
  error: null,
  post: []
};
export default function postReducer(state = initState, action) {
  switch (action.type) {
    case "FETCH_POSTS": {
      return { ...state, fetching: true };
    }
    case "FETCH_POSTS_REJECTED": {
      return { ...state, fetching: false, error: action.payload };
    }
    case "FETCH_POSTS_RECEVIED": {
      return { ...state, fetching: false, fetched: true, post: action.payload };
    }
  }
  return state;
}
