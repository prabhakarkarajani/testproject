import { combineReducers} from 'redux';
//collection of import all reducers here
import posts from './postReducer';
export default combineReducers({
    posts
})
