import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-find-store',
  templateUrl: './find-store.component.html',
  styleUrls: ['./find-store.component.css']
})
export class FindStoreComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
