import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { InfoHeaderComponent } from './core/components/info-header/info-header.component';
import { NavHeaderComponent } from './core/components/nav-header/nav-header.component';
import { FindStoreComponent } from './find-store/find-store.component';
import { AppRoutingModule } from './/app-routing.module';
import { FooterComponent } from './core/footer/footer.component';
import { LoginComponent } from './core/login/login.component';
import { SignupComponent } from './core/signup/signup.component';

@NgModule({
  declarations: [
    AppComponent,
    InfoHeaderComponent,
    NavHeaderComponent,
    FindStoreComponent,
    FooterComponent,
    LoginComponent,
    SignupComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
