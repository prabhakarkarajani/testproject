import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FindStoreComponent } from './find-store/find-store.component';
import { LoginComponent } from './core/login/login.component';
import { SignupComponent } from './core/signup/signup.component';

const routes: Routes = [{
  path: '',
  pathMatch: 'full',
  redirectTo: 'find-store'
},
{
  path: 'find-store',
  component: FindStoreComponent
},
{
  path: 'login',
  component: LoginComponent
},
{
  path: 'signup',
  component: SignupComponent
}
]

@NgModule({
  imports: [
    RouterModule.forRoot(routes)
  ],
  exports: [
    RouterModule
  ]

})
export class AppRoutingModule { }
