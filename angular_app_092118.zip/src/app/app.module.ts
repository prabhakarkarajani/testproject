import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { AppComponent } from './app.component';
import { CoreModule } from './core/core.module';
import { SharedModule } from './shared/shared.module';
//import { CustomersModule } from './customers/customers.module';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AuthResolver } from './core/services/auth.resolver';
import { AuthService } from './core/services/auth.service';
import { AppRoutingModule } from './app-routing.module';
import { EligibilityModule } from './eligibility/eligibility.module';
// import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { HeaderComponent } from './shared/components/header/header.component';
import { MainscreenComponent } from './mainscreen/mainscreen.component';
import { EsrdComponent } from './mainscreen/esrd/esrd.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    HeaderComponent,
    MainscreenComponent,
    EsrdComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    CoreModule,
    SharedModule,
    EligibilityModule,
   // AngularFontAwesomeModule,
   FormsModule, ReactiveFormsModule,
    NgbModule.forRoot()
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  providers: [AuthService, AuthResolver],
  bootstrap: [AppComponent]
})
export class AppModule { }
