import { Component, OnInit } from '@angular/core';
import { FormService } from "src/app/shared/form/service/form.service";
import { InputBase } from "src/app/shared/form/service/input-base";
import { FormBuilder, Validators, ValidatorFn, FormArray, FormGroup, FormControl } from "@angular/forms";
import { DatepickerInput } from "src/app/shared/form/service/datepicker-input";

@Component({
  selector: 'app-esrd',
  templateUrl: './esrd.component.html',
  styleUrls: ['./esrd.component.scss']
})
export class EsrdComponent implements OnInit {
  private isActive: boolean = false;
  inputJSON: InputBase<any>[] = [];
  coordinationFormGroup: FormGroup;
  payload: any = [];
  constructor(private formService: FormService, private fb: FormBuilder) { }

  ngOnInit() {
    this.inputJSON = this.getCoordination();
    this.coordinationFormGroup = this.formService.getFormBuilderArray(this.inputJSON);
  }
  accordionShow() {
    this.isActive = !this.isActive;
  }
  get fbArray() {
    return this.coordinationFormGroup.get('fbArray') as FormArray;
  }
  /** coordination form input data */
  add() {
   // console.log('working');
    
      
      let dateControl = new DatepickerInput({
        key: 'From',
        label: 'From',
        value: '',
        order: 0,
        type: "text",
        validators: [Validators.required]
      });
      let dateControl1 = new DatepickerInput({
        key: 'To',
        label: 'To',
        value: '',
        order: 0,
        type: "text",
        validators: [Validators.required]
      });
      this.fbArray.push(new FormControl(dateControl.value || '', { validators: dateControl["validators"] ? dateControl["validators"] : [], updateOn: 'blur' }));
      this.fbArray.push(new FormControl(dateControl1.value || '', { validators: dateControl1["validators"] ? dateControl1["validators"] : [], updateOn: 'blur' }));
      this.inputJSON.push(dateControl, dateControl1);
      //this.coordinationFormGroup = this.formService.getFormBuilderArray(this.inputJSON);
  
  }
  deleteCoordinationDates(i){
    console.log(i);
    this.inputJSON.splice(i,2);
    //this.coordinationFormGroup = this.formService.getFormBuilderArray(this.inputJSON);
    this.coordinationFormGroup.removeControl(i);
    this.coordinationFormGroup.removeControl(i+1);
  }
  


  getCoordination() {
    let inputJSON: InputBase<any>[] = [
      new DatepickerInput({
        key: 'From',
        label: 'From',
        value: '',
        order: 0,
        type: "text",
        validators: [Validators.required]
      }),
      new DatepickerInput({
        key: 'To',
        label: 'To',
        value: '',
        order: 0,
        type: "text",
        validators: [Validators.required]
      }),


    ];

    return inputJSON.sort((a, b) => a.order - b.order);
  }
}
