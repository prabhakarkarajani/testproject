import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EsrdComponent } from './esrd.component';

describe('EsrdComponent', () => {
  let component: EsrdComponent;
  let fixture: ComponentFixture<EsrdComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EsrdComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EsrdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
