import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-eligibility-start',
  templateUrl: './eligibility-start.component.html',
  styleUrls: ['./eligibility-start.component.scss']
})
export class EligibilityStartComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }

  navigateTo() {
    console.log('triggerd');
    this.router.navigateByUrl('eligibilityDashboard')
  }

}
