import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EligibilityStartComponent } from './eligibility-start.component';

describe('EligibilityStartComponent', () => {
  let component: EligibilityStartComponent;
  let fixture: ComponentFixture<EligibilityStartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EligibilityStartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EligibilityStartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
