import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { EligibilityDashboardComponent } from './eligibility-dashboard/eligibility-dashboard.component';
import { EligibilityStartComponent } from './eligibility-start/eligibility-start.component';
const routes: Routes = [{
  path: '',
  component: EligibilityStartComponent
},
{
  path: 'eligibilityDashboard',
  component: EligibilityDashboardComponent
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class EligibilityRoutingModule { }
