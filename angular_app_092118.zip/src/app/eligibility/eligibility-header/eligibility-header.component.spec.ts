import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EligibilityHeaderComponent } from './eligibility-header.component';

describe('EligibilityHeaderComponent', () => {
  let component: EligibilityHeaderComponent;
  let fixture: ComponentFixture<EligibilityHeaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EligibilityHeaderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EligibilityHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
