import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eligibility-header',
  templateUrl: './eligibility-header.component.html',
  styleUrls: ['./eligibility-header.component.scss']
})
export class EligibilityHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
