import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EligibilityOutputComponent } from './eligibility-output.component';

describe('EligibilityOutputComponent', () => {
  let component: EligibilityOutputComponent;
  let fixture: ComponentFixture<EligibilityOutputComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EligibilityOutputComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EligibilityOutputComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
