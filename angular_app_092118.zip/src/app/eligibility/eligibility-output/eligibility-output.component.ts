import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eligibility-output',
  templateUrl: './eligibility-output.component.html',
  styleUrls: ['./eligibility-output.component.scss']
})
export class EligibilityOutputComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
