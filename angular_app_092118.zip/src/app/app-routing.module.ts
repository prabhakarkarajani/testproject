import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from 'src/app/dashboard/dashboard.component';
import { AuthResolver } from './core/services/auth.resolver';
import { MainScreenModule } from './main-screen/main-screen.module';
import { CustomersModule } from './customers/customers.module'
import { EligibilityModule } from './eligibility/eligibility.module';
import { MainscreenComponent } from './mainscreen/mainscreen.component';
const routes: Routes = [
  // {
  //   path: '',
  //   component: DashboardComponent,
  //   resolve: {
  //     token: AuthResolver
  //   }
  // },
  {
    path: 'customers',
    loadChildren: () => CustomersModule
  },
  // {
  //   path: '',
  //   loadChildren: () => EligibilityModule
  // },
  {
    path:'',
    component:MainscreenComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
