import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ModalComponent } from './components/modal/modal.component';
import { FormComponent } from './form/form.component';
import { ReactiveFormsModule } from '@angular/forms';
import { InputElementsFactoryComponent } from './form/input-elements-factory/input-elements-factory.component';
import { CalltimerComponent } from './components/calltimer/calltimer.component';


@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule
  ],
  declarations: [ModalComponent, FormComponent, InputElementsFactoryComponent, CalltimerComponent],
  exports: [FormComponent, CalltimerComponent, ModalComponent]
})
export class SharedModule { }
