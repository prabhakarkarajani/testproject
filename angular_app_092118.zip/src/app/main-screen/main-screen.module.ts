import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
// import { InputComponent } from './input/input.component';
// import { OutputComponent } from './output/output.component';
import { routing } from "./app-routing.module";
import { MainScreenComponent } from './main-screen.component';

@NgModule({
  imports: [
    CommonModule,
    routing
  ],
  declarations: [ MainScreenComponent]
})
export class MainScreenModule { }
