// This file can be replaced during build by using the `fileReplacements` array.
// `ng build ---prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  AUTH_URL: '/assets/models/auth.json',
  Get_Queues: 'http://172.23.177.211:8099/CCVUnification/api/queues',
  Get_User: 'http://172.23.177.211:8099/CCVUnification/api/users',
  Add_User: 'http://172.23.177.211:8099/CCVUnification/api/user/addUser ',
  Update_User: 'http://172.23.177.211:8099/CCVUnification/api/user/updateUser',
  Delete_User: 'http://172.23.177.211:8099/CCVUnification/api/user/deleteUser',
  Smart_Search: 'http://172.23.177.211:8099/CCVUnification/api/usersetup',
  Login: 'http://172.23.177.215:8097/CCVUnification/api/login'
};
/*
 * In development mode, for easier debugging, you can ignore zone related error
 * stack frames such as `zone.run`/`zoneDelegate.invokeTask` by importing the
 * below file. Don't forget to comment it out in production mode
 * because it will have a performance impact when errors are thrown
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
