import { Component, OnInit } from '@angular/core';
import { fadeInOut } from '../router.animations';

@Component({
  selector: 'app-mainscreen',
  templateUrl: './main-screen.component.html',
  styleUrls: ['./main-screen.component.scss'],
  animations: [fadeInOut()]
})
export class MainScreenComponent implements OnInit {
  constructor( ) { }

  ngOnInit() {
  }

}
