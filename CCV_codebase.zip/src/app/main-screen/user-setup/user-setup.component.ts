import { Component, OnInit } from '@angular/core';
import { HttpConnectorService } from '../../shared/services/http-connector.service';
import { environment } from '../../../environments/environment';
import { fadeInOut } from '../../router.animations';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
    selector: 'app-user-setup',
    templateUrl: './user-setup.component.html',
    styleUrls: ['./user-setup.component.scss'],
    animations: [fadeInOut()]
})
export class UserSetupComponent implements OnInit {
    users: any;
    states: any;
    lobs: any;
    registerForm: FormGroup;
    submitted = false;
    isActive: boolean = false;
    constructor(private HttpConnector: HttpConnectorService, private formBuilder: FormBuilder) { }

    ngOnInit() {
        this.usersList();
        this.formReg();

    }

    formReg(val?) {

        this.registerForm = this.formBuilder.group({
            id: [val ? val.id : '', ''],
            userId: [val ? val.userId : '', Validators.required],
            firstName: [val ? val.firstName : '', Validators.required],
            lastName: [val ? val.lastName : '', Validators.required],
            userType: [val ? val.userType : '', Validators.required],
            reportingManager: [val ? val.reportingManager : '', Validators.required],
            auditType: [val ? val.auditType : '', Validators.required],
            probation: [val ? val.probation : '', Validators.required],
            employeeLocation: [val ? val.employeeLocation : '', Validators.required],
            preOrPost: [val ? val.preOrPost : '', ''],
            payer: [val ? val.payer : '', Validators.required],
            state: [val ? val.state : '', Validators.required],
            lob: [val ? val.lob : '', Validators.required],
            appealLevel: [val ? val.appealLevel : '', Validators.required],

        });

        if (val && val.payer === 'Anthem') {
            this.states = [{ value: "New York", key: "New York" }]
            this.lobs = [{ value: "Medicaid", key: "Medicaid" }, { value: "Medicare", key: "Medicare" }];
            this.registerForm.get('lob').setValidators([Validators.required]);
            this.registerForm.get('state').setValue(val.state);
            this.registerForm.get('lob').setValue(val.lob)
        } else if (val && val.payer === 'BCBS') {

            this.states = [{ value: "Massachusetts", key: "Massachusetts" }, { value: "New York", key: "New York" }];
            this.lobs = [{ value: "Medicaid", key: "Medicaid" }];
            this.registerForm.get('lob').setValidators([Validators.required]);
            this.registerForm.get('state').setValue(val.state);
            this.registerForm.get('lob').setValue(val.lob)
        } else if (val && val.payer === 'UHG') {

            this.states = [{ value: "California", key: "California" }, { value: "Medicare", key: "Medicare" }];
            this.lobs = [];
            this.registerForm.get('lob').clearValidators();
            this.registerForm.get('lob').updateValueAndValidity();
            this.registerForm.get('state').setValue(val.state)
        }

        if (val && val.userType != 'Audit Manager') {
            this.registerForm.get('appealLevel').enable()
        }else{
          this.registerForm.get('appealLevel').disable()
        }
    }

    // convenience getter for easy access to form fields
    get f() { return this.registerForm.controls; }



    onSubmit(val?) {
        this.submitted = true;

        // stop here if form is invalid
        if (this.registerForm.invalid) {
            return;
        }

        
        this.HttpConnector.postRequest(environment.Add_User, this.registerForm.value).subscribe(response => {
            console.log(response)
            this.usersList();

            this.registerForm.reset();
        });
        console.log(this.registerForm.value);

        // alert('SUCCESS!! :-)')

        // this.HttpConnector.getRequest(environment.Get_User).subscribe(response => {
        //   // this.users = response;
        // });

        // firstName: ['', [Validators.required]],
        // userId: ['', [Validators.required]],
        // userType: ['', [Validators.required]],
        // superisor: ['', [Validators.required]],
        // lastName: ['', [Validators.required]],
        // role: ['', [Validators.required]],
        // reportingManager: ['', [Validators.required]],
        // auditType: ['', [Validators.required]],
        // probation: ['', [Validators.required]],
        // employeeLocation: ['', [Validators.required]],
        // preOrPost: ['', [Validators.required]],
        // payer: ['', [Validators.required]],





        // "firstName":"Prabhakar",
        // "userId":"E106",
        // "userType":"Manager",
        // "superisor":"yes",
        // "lastName":"Miryala",
        // "role":"manager",
        // "reportingManager":"Anthony",
        // "auditType":"initial",
        // "probation":"no",
        // "employeeLocation":"Hyd",
        // "preOrPost":"pre",
        // "payer":"ABC"



    }

    reset() {
        this.registerForm.reset();

    }
    /**get the selected option value */
    selectChangeHandler(event: any) {
        let selectedPayer = event.target.value;
        if (selectedPayer === 'Anthem') {
            this.states = [{ value: "New York", key: "New York" }]
            this.lobs = [{ value: "Medicaid", key: "Medicaid" }, { value: "Medicare", key: "Medicare" }];
            this.registerForm.get('lob').setValidators([Validators.required]);
            this.registerForm.get('state').setValue("")
            this.registerForm.get('lob').setValue("")
        } else if (selectedPayer === 'BCBS') {

            this.states = [{ value: "Massachusetts", key: "Massachusetts" }, { value: "New York", key: "New York" }];
            this.lobs = [{ value: "Medicaid", key: "Medicaid" }];
            this.registerForm.get('lob').setValidators([Validators.required]);
            this.registerForm.get('state').setValue("")
            this.registerForm.get('lob').setValue("")
        } else {

            this.states = [{ value: "California", key: "California" }, { value: "Medicare", key: "Medicare" }];
            this.lobs = [];
            this.registerForm.get('lob').clearValidators();
            this.registerForm.get('lob').updateValueAndValidity();
            this.registerForm.get('state').setValue("")
            this.registerForm.get('lob').setValue("")
        }



    }
    /** ROLE CHAGNE HANDLER */
    roleChangeHandler(event: any) {
        if (event.target.value == 'Audit Manager') {
            this.registerForm.get('appealLevel').enable()
        } else {
          this.registerForm.get('appealLevel').setValue("")
          this.registerForm.get('appealLevel').disable()
        }

    }
    usersList() {

        this.HttpConnector.getRequest(environment.Get_User).subscribe(response => {
            this.users = response;
        });
    }
    add() {
        this.HttpConnector.postRequest(environment.Add_User, '').subscribe(response => {
            this.users = response;
        });
    }
    edit(val) {
        console.log(val)
        this.formReg(val);
        // this.HttpConnector.postRequest(environment.Update_User, '').subscribe(response => {
        //   this.users = response;
        // });
    }
    delete(id) {
        const idReq = {
            id: id
        }
        this.HttpConnector.postRequest(environment.Delete_User, idReq).subscribe(response => {

            this.usersList();

        });
    }
}
