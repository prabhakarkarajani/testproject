import { Component, OnInit } from '@angular/core';
import { fadeInOut } from '../../router.animations';
import { HttpConnectorService } from '../../shared/services/http-connector.service';
import { environment } from '../../../environments/environment';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
  animations: [fadeInOut()]
})
export class DashboardComponent implements OnInit {
  queues:any;
  payer = 'Anthem';
  file = 'Retro';
  constructor(private HttpConnector: HttpConnectorService) { }

  ngOnInit() {
    this.queuesList();
  }
  queuesList() {
    if (this.payer && this.file) {
      this.HttpConnector.getRequest(environment.Get_Queues + '/' + this.payer + '/' + this.file).subscribe(response => {
        this.queues = response;
        console.log(this.queues)
      });
    }
  }


  // requestData() {
  //   console.log(this.payer);
  // }
}
