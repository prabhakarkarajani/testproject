import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MainScreenRoutingModule } from './main-screen-routing.module';
import { SharedModule } from "src/app/shared/shared.module";
import { NgbModule } from "@ng-bootstrap/ng-bootstrap";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DashboardComponent } from './dashboard/dashboard.component';
import { UserSetupComponent } from './user-setup/user-setup.component';
import { MainScreenComponent } from './main-screen.component';
import { SidebarComponent } from '../shared/components/sidebar/sidebar.component';


@NgModule({
  imports: [
    CommonModule,
    MainScreenRoutingModule,
    SharedModule,
    NgbModule.forRoot()
  ],
  declarations: [MainScreenComponent, DashboardComponent, UserSetupComponent, SidebarComponent]
})
export class MainScreenModule { }
