import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html'
})
export class HeaderComponent implements OnInit {
  name;
  constructor(public router: Router ) { }
  public title: string;
  ngOnInit() {
    this.title = "Eligibilty"
    this.name = localStorage.getItem('name');


  }
  logout() {
    localStorage.removeItem('isLoggedin');
    localStorage.removeItem('name');
    this.router.navigate(['login']);

  }
}
