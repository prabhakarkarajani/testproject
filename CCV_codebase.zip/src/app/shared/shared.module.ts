import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ModalComponent } from './components/modal/modal.component';
import { FormComponent } from './form/form.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { InputElementsFactoryComponent } from './form/input-elements-factory/input-elements-factory.component';
import { CalltimerComponent } from './components/calltimer/calltimer.component';
import { SharedTestComponent } from './components/shared-test/shared-test.component';
import { HeaderComponent } from './components/header/header.component';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
  ],
  declarations: [ModalComponent, FormComponent, InputElementsFactoryComponent, CalltimerComponent,
    SharedTestComponent, HeaderComponent, ],
  exports: [
    FormsModule,
    ReactiveFormsModule,

    FormComponent, CalltimerComponent, ModalComponent, SharedTestComponent, HeaderComponent]
})
export class SharedModule { }
