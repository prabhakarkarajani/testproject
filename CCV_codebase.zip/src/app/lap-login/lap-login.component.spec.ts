import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LapLoginComponent } from './lap-login.component';

describe('LapLoginComponent', () => {
  let component: LapLoginComponent;
  let fixture: ComponentFixture<LapLoginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LapLoginComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LapLoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
