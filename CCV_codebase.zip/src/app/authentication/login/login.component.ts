import { Component, OnInit } from '@angular/core';
import { HttpConnectorService } from '../../shared/services/http-connector.service';
import { Router } from '@angular/router';
import { fadeInOut } from '../../router.animations';
import { environment } from '../../../environments/environment';

import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
  animations: [fadeInOut()]
})
export class LoginComponent implements OnInit {
  loginData = {
    username: '',
    password: ''
  };
  loginForm: FormGroup;
  submitted = false;
  errosMsg = false;
  constructor(private HttpConnector: HttpConnectorService, public router: Router, private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', [Validators.required]]
    });
  }
  // convenience getter for easy access to form fields
  get f() { return this.loginForm.controls; }



  onSubmit() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.loginForm.invalid) {
      return;
    }

    // alert('SUCCESS!! :-)')
    // debugger
    this.HttpConnector.postRequest(environment.Login, this.loginForm.value).subscribe(response => {
      // this.users = response;




      // this.HttpConnector.postRequest(environment.Add_User, this.registerForm.value).subscribe(response => {

      console.log(response.statusCode)
      console.log(this.errosMsg)

      if (response.statusCode == 'OK') {
        this.errosMsg = false;

        const name = response.userName.match(/^([^@]*)@/)[1];
        localStorage.setItem('isLoggedin', 'true');
        localStorage.setItem('name', name);

        this.router.navigate(['secure']);
      } else {
        alert('User name or Password is incorrect')
        this.errosMsg = true;
      }
      console.log(this.errosMsg)

    });
  }

}
