import { RuleEngineUtils } from "src/app/rule-engine/rule-engine-utils";
import { Configurtion } from "src/app/rule-engine/configuration";
import { DataSharingService } from "src/app/core/services/data-sharing.service";

export class InCenterESRDRule implements Rule {
    private input;
    private eventsList;
    private corordinationDateList = [];
    public constructor(input: any, corordinationDateList: any[], private dataSharingService:DataSharingService) {
        this.input = input;
        this.corordinationDateList = corordinationDateList;       
    }

    execute(): any {
        console.log("InCenterESRDRule");
        if (this.input["event"] = "incenter") {
            let inCenterEventRepeatedCount = 0;
            //checking if the incenter event is triggered more than once
            /*this.corordinationDateList.forEach(element => {
                if (element["event"] = "incenter") {
                    inCenterEventRepeatedCount = inCenterEventRepeatedCount+1;
                }
            });*/
            
            let coord_start_date = RuleEngineUtils.addonMonths(this.input["treatment"], Configurtion.WAITING_PERIOD);
            let coord_end_date = RuleEngineUtils.addonMonths(this.input["treatment"], Configurtion.COORDINATION_PERIOD_DURATON + Configurtion.WAITING_PERIOD);
            //if incenter event is triggered more than once, the later one's waiting period is waived
            if (this.corordinationDateList.length > 1) {
                coord_start_date = RuleEngineUtils.addonMonths(this.input["treatment"], 0);
                coord_end_date = RuleEngineUtils.addonMonths(this.input["treatment"], Configurtion.COORDINATION_PERIOD_DURATON);

            }
            //Coordination start dates start with 1st of the month
            coord_start_date = RuleEngineUtils.setDayInMonth(coord_start_date, 1);
            //Get the maximum days in a month
            let maxDaysinMonth = RuleEngineUtils.getMaximumDaysInaMonth(coord_end_date);
            ///Coordination end dates end's with last day of the month
            coord_end_date = RuleEngineUtils.setDayInMonth(coord_end_date, maxDaysinMonth);

            this.input["coordination_start"] = coord_start_date;
            this.input["coordination_end"] = coord_end_date;
            this.input["entitlement_start"] = coord_start_date;
            this.input["entitlement_end"] = "infinity"
            //Checking for overlapping coordination dates with previous list of coordination period dates
            let isCoordinationPeriodOverlapped = false;
            this.corordinationDateList.forEach(element => {
                if (element.entitlement_end && element.entitlement_end != "infinity") {
                    if (new Date(coord_start_date) < new Date(element["entitlement_end"])) {
                        isCoordinationPeriodOverlapped = true;
                    }
                } else {
                    if (new Date(coord_start_date) < new Date(element["coordination_end"]) || new Date(coord_start_date) > new Date(element["coordination_end"])) {
                        isCoordinationPeriodOverlapped = true;
                    }
                }
            });
            if (!isCoordinationPeriodOverlapped) {
                this.corordinationDateList.push(this.input);
            }
            console.log(this.corordinationDateList);
            this.dataSharingService.coordinationDates = this.corordinationDateList;
            return this.dataSharingService.coordinationDates;
        }
    }
}