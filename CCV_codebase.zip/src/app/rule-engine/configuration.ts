export class Configurtion{
    constructor(){

    }

    public static WAITING_PERIOD = 3; //3 months
    public static COORDINATION_PERIOD_DURATON = 30; //30 months  
    public static ESRD_TERMINATAION_TRANSPLANT_DURATION = 36; //36 months  
}