import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router'
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private _router: Router) { }
  loginUserData = {}
  ngOnInit() {
  }
  loginUser() {
    
    console.log(this.loginUserData);

    let userData = this.loginUserData;
    if (userData) {
      console.log('true')
      localStorage.setItem('token', 'prabhakar');
      this._router.navigate(['/find-store'])
    } else {
      console.log('false');
    }
    // this._auth.loginUser(this.loginUserData)
    // .subscribe(
    //   res => {
    //     localStorage.setItem('token', res.token)
    //     this._router.navigate(['/special'])
    //   },
    //   err => console.log(err)
    // ) 
  }
}
