import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { debounceTime, distinctUntilChanged, map } from 'rxjs/operators';
import { HttpConnectorService } from "src/app/shared/service/http-connector.service";
import { environment } from "src/environments/environment";
import { DataSharingService } from "src/app/core/services/data-sharing.service";
@Component({
  selector: 'app-find-store',
  templateUrl: './find-store.component.html',
  styleUrls: ['./find-store.component.css']
})
export class FindStoreComponent implements OnInit {
  public medicineData: any;
  public model: any;
  public searchArr: any;
  public medicineUse: String;
  constructor(private HttpConnector: HttpConnectorService, private dataSharedService: DataSharingService) { }

  ngOnInit() {
    this.HttpConnector.getRequest(environment.GET_MED_DATA).subscribe(response => {
      this.dataSharedService.getMedData = response;
      const dupArr = this.dataSharedService.getMedData.map(obj => obj.name);
      this.medicineData = Array.from(new Set(dupArr))
      // this.medicineData = dupArr.filter((value) => {
      //   return !this[value] && (this[value] = true)
      // }, Object.create(null))
      console.log(this.medicineData)
    });

    this.HttpConnector.getRequest(environment.GET_MEDICINE_INFO).subscribe(response => {
      this.dataSharedService.getMedicineInfo = response;
    })
    // let local = `?location=17.361720,78.475170
    // &radius=500
    // &types=health
    // &name=harbour
    // &key=AIzaSyB5Y75urLCtp5vYRmWGx0zaSJiy5kyRuTE`;

    // this.HttpConnector.getRequest(environment.GET_NEAR_PLACES+local).subscribe(response => {
    //   console.log(response);
    // })
    this.getLocation();
    
  }

  /**get the current geolocation */
   getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(this.showPosition);
    } else { 
       console.log("Geolocation is not supported by this browser.");
    }
}
showPosition(position) {
  console.log("Latitude: " + position.coords.latitude + 
    "<br>Longitude: " + position.coords.longitude);
}

  search = (text$: Observable<string>) => text$.pipe(debounceTime(200), distinctUntilChanged(), map(term => term === '' ? [] : this.medicineData.filter(v => v.toLowerCase().indexOf(term.toLowerCase()) > -1).slice(0, 10)));

  /**search handler */
  getMedicineData(data) {
    this.searchArr = [];
    this.searchArr = this.dataSharedService.getMedData.filter(obj => obj.name === data);
    this.medicineUse = this.dataSharedService.getMedicineInfo[data];
    console.log(this.getDistanceFromLatLonInKm(17.361720,78.475170,17.4142,78.4117))
  }

   getDistanceFromLatLonInKm(lat1,lon1,lat2,lon2) {
    var R = 6371; // Radius of the earth in km
    var dLat = this.deg2rad(lat2-lat1);  // deg2rad below
    var dLon = this.deg2rad(lon2-lon1); 
    var a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(this.deg2rad(lat1)) * Math.cos(this.deg2rad(lat2)) * 
      Math.sin(dLon/2) * Math.sin(dLon/2); 
    var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
    var d = R * c; // Distance in km
    return d;
  }
  
  deg2rad(deg) {
    return deg * (Math.PI/180)
  };

  
}
