export const environment = {
  production: true,
  AUTH_URL:'/assets/models/auth.json',
   GET_TASK:'/assets/models/getTask.json',
  SET_TASK:'/assets/models/getTask.json'
};
