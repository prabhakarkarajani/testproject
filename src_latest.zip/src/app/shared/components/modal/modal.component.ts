import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { InputBase } from "src/app/shared/form/service/input-base";
import { TextInput } from "src/app/shared/form/service/text-input.";
import { FormBuilder } from '@angular/forms';
import { Validators } from "@angular/forms";
import { ValidatorFn } from "@angular/forms";
import { AbstractControl } from "@angular/forms";
import { FormControl } from "@angular/forms";
import { SelectInput } from "src/app/shared/form/service/select-input";
import { DataSharingService } from "src/app/core/services/data-sharing.service";
@Component({
  selector: 'app-modal',
  templateUrl: './modal.component.html',
  styleUrls: ['./modal.component.scss']
})
export class ModalComponent implements OnInit {

  ngOnInit(): void {
    this.memberAndMedicaredata = this.getInputJSON();
    this.note = this.dataSharedService.getTaskData["memberdetails"].notes;
  }

  closeResult: string;
  editData: any;
  memberAndMedicaredata: InputBase<any>[] = [];
  @Output() saveEditData = new EventEmitter<any>();
  note:any;

  constructor(private modalService: NgbModal, private dataSharedService: DataSharingService) { }

  open(content) {


    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title', size: 'lg' }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  getInputJSON() {

    let inputJSON: InputBase<any>[] = [
      new TextInput({
        key: 'Enter Data for Field',
        label: 'Enter Data for Field',
        value: '',
        order: 2,
        type: "text",
        validators: [Validators.required]
      }),

      new SelectInput({
        key: 'Choose Field Name',
        label: 'Choose Field Name',
        options: [
          { key: 'firstname', value: 'First Name' },
          { key: 'lastname', value: 'Last Name' },
          { key: 'ssn', value: 'SSN' },
          { key: 'middle', value: 'Middle Name' },
          { key: 'suffix', value: 'Suffix' }
        ],
        order: 1,
        validators: [Validators.required]
      })
    ];

    return inputJSON.sort((a, b) => a.order - b.order);
  }


  getEditData(obj: any) {
    this.editData = obj;
  }

  onSave(modal) {
    this.editData.forEach((element, index) => {
      this.editData[index].key = element.key.toLowerCase().replace(/\s/g, '');

    });
    this.saveEditData.emit(this.editData);
    modal.close()
  }

}
