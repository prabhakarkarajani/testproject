import { Component, OnInit, Input, ViewChild, EventEmitter, Output } from '@angular/core';
import { FormService } from "src/app/shared/form/service/form.service";
import { InputBase } from "src/app/shared/form/service/input-base";
import { FormBuilder } from "@angular/forms";
import { FormArray } from "@angular/forms";
import { TextInput } from "src/app/shared/form/service/text-input.";

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.scss'],
  providers: [FormService]
})
export class FormComponent implements OnInit {
  inputJSON: InputBase<any>[] = [];
  formGroupObj: any;
  payload: any = [];

  @Input() formTitle: string;
  @Input() formData:InputBase<any>[];
  @Output() modifiedEditData = new EventEmitter<any>();
  constructor(private formService: FormService, private fb: FormBuilder) {    
  }

  ngOnInit() {
    this.inputJSON = this.formData;
    console.log(this.formData);
    //this.inputJSON = this.formService.getInputJSON(this.formData);
    this.formGroupObj = this.formService.getFormBuilderArray(this.formData);
  }
  get fbArray() {
    return this.formGroupObj.get('fbArray') as FormArray;
  }


  addList(data) {
    let updateInputs = {
      key: data.fbArray[0],
      value: data.fbArray[1]
    }
    this.payload.push(updateInputs);
    this.modifiedEditData.emit(this.payload);
  }

  removeItem(i) {
    let removeIndex = this.payload.map(function (item) { return item.key; }).indexOf(i.key);
    this.payload.splice(removeIndex, 1);
  }
  submit() {
  }

}
