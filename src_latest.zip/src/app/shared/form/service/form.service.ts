import { Injectable } from '@angular/core';
import { InputBase } from "src/app/shared/form/service/input-base";
import { TextInput } from "src/app/shared/form/service/text-input.";
import { FormBuilder } from '@angular/forms';
import { Validators } from "@angular/forms";
import { ValidatorFn } from "@angular/forms";
import { AbstractControl } from "@angular/forms";
import { FormControl } from "@angular/forms";
import { SelectInput } from "src/app/shared/form/service/select-input";

@Injectable({
  providedIn: 'root'
})
export class FormService {
  min: number = 20;
  max: number = 60;
  constructor(private fb: FormBuilder) { }
  data: any;
  getFormBuilderArray(data) {
    //let formObject: InputBase<any>[] = this.getInputJSON();
    let formObject: InputBase<any>[] = data;
    let formBilderArray: any[] = [];
    let formGroup;
    if (formObject) {
      formObject.forEach(elemnt => {
        formBilderArray.push(new FormControl(elemnt.value || '', { validators: elemnt["validators"] ? elemnt["validators"] : [] }));
      })
      formGroup = this.fb.group({
        fbArray: this.fb.array(formBilderArray)
      })
    }

    console.log(formGroup)
    return formGroup;
  }
  ageRangeValidator(min: number, max: number): ValidatorFn {
    return (control: AbstractControl): { [key: string]: boolean } | null => {
      let value = +control.value;
      if (value > 0 && (value < min || value > max)) {
        control.setValue(0);
        return { 'ageRange': true };
      }
      return null;
    };
  }

}
