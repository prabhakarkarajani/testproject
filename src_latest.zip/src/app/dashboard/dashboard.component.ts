import { Component, OnInit } from '@angular/core';
import { AuthService } from '../core/services/auth.service'
import { ActivatedRoute } from "@angular/router";
import { DataSharingService } from "src/app/core/services/data-sharing.service";

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  private worktype:String = 'My Work Dashboard';
  constructor(private auth:AuthService, private route: ActivatedRoute, private dataSharedService:DataSharingService) { }

  ngOnInit() {
    this.auth.authToken = this.route.snapshot.data["token"];
    this.dataSharedService.test = "changed in dashboard"
  }

}
