import { Component, OnInit } from '@angular/core';
import { HttpConnectorService } from "src/app/shared/services/http-connector.service";
import { DataSharingService } from "src/app/core/services/data-sharing.service";
import { environment } from "src/environments/environment";

@Component({
  selector: 'app-task-screen',
  templateUrl: './task-screen.component.html',
  styleUrls: ['./task-screen.component.scss']
})
export class TaskScreenComponent implements OnInit {

  constructor(private HttpConnector: HttpConnectorService, private dataSharedService: DataSharingService) { }
  taskData: any;
  ngOnInit() {
    this.HttpConnector.getRequest(environment.GET_TASK).subscribe(response => {      
      this.dataSharedService.getTaskData = JSON.parse(response.test_sting);  
      this.dataSharedService.id = response.id;    
      this.taskData = this.dataSharedService.getTaskData["takDetails"];

    });
  }
}
