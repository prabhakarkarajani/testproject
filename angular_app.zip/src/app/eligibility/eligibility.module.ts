import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EligibilityRoutingModule } from './eligibility-routing.module';
import { EligibilityDashboardComponent } from './eligibility-dashboard/eligibility-dashboard.component';
import { EligibilityHeaderComponent } from './eligibility-header/eligibility-header.component';
import { EligibilityInputComponent } from './eligibility-input/eligibility-input.component';
import { EligibilityOutputComponent } from './eligibility-output/eligibility-output.component';


import { SharedModule } from "../shared/shared.module";
import { EligibilityStartComponent } from './eligibility-start/eligibility-start.component';

@NgModule({
  imports: [
    CommonModule,
    EligibilityRoutingModule,
    SharedModule
  ],
  declarations: [EligibilityDashboardComponent, EligibilityHeaderComponent, EligibilityInputComponent, EligibilityOutputComponent, EligibilityStartComponent]
})
export class EligibilityModule { }
