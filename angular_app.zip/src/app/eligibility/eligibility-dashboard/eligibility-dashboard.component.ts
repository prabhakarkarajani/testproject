import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eligibility-dashboard',
  templateUrl: './eligibility-dashboard.component.html',
  styleUrls: ['./eligibility-dashboard.component.scss']
})
export class EligibilityDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
