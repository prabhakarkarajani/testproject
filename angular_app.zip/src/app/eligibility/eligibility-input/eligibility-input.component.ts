import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eligibility-input',
  templateUrl: './eligibility-input.component.html',
  styleUrls: ['./eligibility-input.component.scss']
})
export class EligibilityInputComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
