import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { InputComponent } from './input/input.component';
import { OutputComponent } from './output/output.component';
import { routing } from "./app-routing.module";

@NgModule({
  imports: [
    CommonModule,
    routing
  ],
  declarations: [InputComponent, OutputComponent]
})
export class MainScreenModule { }
